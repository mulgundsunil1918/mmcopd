PRAGMA foreign_keys=OFF;
BEGIN;
CREATE TABLE schema_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
CREATE TABLE patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uhid TEXT NOT NULL UNIQUE,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      dob TEXT NOT NULL,
      gender TEXT NOT NULL CHECK (gender IN ('M','F','Other')),
      phone TEXT NOT NULL,
      email TEXT,
      address TEXT,
      blood_group TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , place TEXT, district TEXT, state TEXT, profession TEXT, registration_fee_paid INTEGER NOT NULL DEFAULT 0, registration_fee_paid_at TEXT, row_version INTEGER NOT NULL DEFAULT 1);
CREATE TABLE doctors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      specialty TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      room_number TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      default_fee REAL NOT NULL DEFAULT 500
    , signature TEXT, qualifications TEXT, registration_no TEXT, color TEXT, available_from TEXT, available_to TEXT, template_id INTEGER, template_id_2 INTEGER, template_id_3 INTEGER, template_slot_names TEXT);
CREATE TABLE appointments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      doctor_id INTEGER NOT NULL REFERENCES doctors(id),
      appointment_date TEXT NOT NULL,
      appointment_time TEXT NOT NULL,
      token_number INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'Waiting',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , consultation_token TEXT, row_version INTEGER NOT NULL DEFAULT 1, visit_number INTEGER, visit_id TEXT, patient_group TEXT, procedure_tags TEXT, referred_by TEXT);
CREATE TABLE notification_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      sent_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );
CREATE TABLE consultations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id) ON DELETE CASCADE,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      doctor_id INTEGER NOT NULL REFERENCES doctors(id),
      history TEXT,
      vitals_json TEXT,
      examination TEXT,
      impression TEXT,
      advice TEXT,
      follow_up_date TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    , row_version INTEGER NOT NULL DEFAULT 1, extra_fields_json TEXT);
CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      role TEXT NOT NULL,
      display_name TEXT,
      doctor_id INTEGER REFERENCES doctors(id),
      is_active INTEGER NOT NULL DEFAULT 1,
      last_login_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , must_change_password INTEGER NOT NULL DEFAULT 0);
CREATE TABLE audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      username TEXT,
      role TEXT,
      action TEXT NOT NULL,
      entity TEXT,
      entity_id INTEGER,
      details TEXT,
      at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE prescription_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      appointment_id INTEGER NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
      drug_name TEXT NOT NULL,
      dosage TEXT,
      frequency TEXT,
      duration TEXT,
      instructions TEXT,
      order_idx INTEGER NOT NULL DEFAULT 0
    , drug_master_id INTEGER REFERENCES drug_master(id));
CREATE TABLE lab_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price REAL NOT NULL DEFAULT 0,
      sample_type TEXT,
      ref_range TEXT,
      unit TEXT,
      is_active INTEGER NOT NULL DEFAULT 1
    , category TEXT NOT NULL DEFAULT 'pathology');
CREATE TABLE lab_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT NOT NULL UNIQUE,
      appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      doctor_id INTEGER REFERENCES doctors(id),
      status TEXT NOT NULL DEFAULT 'ordered',
      ordered_at TEXT NOT NULL DEFAULT (datetime('now')),
      collected_at TEXT,
      reported_at TEXT,
      notes TEXT
    );
CREATE TABLE lab_order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      lab_order_id INTEGER NOT NULL REFERENCES lab_orders(id) ON DELETE CASCADE,
      lab_test_id INTEGER REFERENCES lab_tests(id),
      test_name TEXT NOT NULL,
      result TEXT,
      unit TEXT,
      ref_range TEXT,
      is_abnormal INTEGER DEFAULT 0
    );
CREATE TABLE drug_inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      generic_name TEXT,
      form TEXT,
      strength TEXT,
      mrp REAL NOT NULL DEFAULT 0,
      purchase_price REAL,
      batch TEXT,
      expiry TEXT,
      stock_qty INTEGER NOT NULL DEFAULT 0,
      low_stock_threshold INTEGER NOT NULL DEFAULT 10,
      is_active INTEGER NOT NULL DEFAULT 1
    );
CREATE TABLE pharmacy_sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_number TEXT NOT NULL UNIQUE,
      patient_id INTEGER REFERENCES patients(id),
      appointment_id INTEGER REFERENCES appointments(id),
      subtotal REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      payment_mode TEXT,
      sold_by TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , taxable_total REAL NOT NULL DEFAULT 0, exempt_total REAL NOT NULL DEFAULT 0, cgst_total REAL NOT NULL DEFAULT 0, sgst_total REAL NOT NULL DEFAULT 0, is_tax_invoice INTEGER NOT NULL DEFAULT 0);
CREATE TABLE pharmacy_sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL REFERENCES pharmacy_sales(id) ON DELETE CASCADE,
      drug_id INTEGER REFERENCES drug_inventory(id),
      drug_name TEXT NOT NULL,
      qty INTEGER NOT NULL,
      rate REAL NOT NULL,
      amount REAL NOT NULL
    , drug_master_id INTEGER REFERENCES drug_master(id), batch_id INTEGER REFERENCES drug_stock_batches(id), gst_amount REAL DEFAULT 0, gst_rate REAL NOT NULL DEFAULT 0, cgst REAL NOT NULL DEFAULT 0, sgst REAL NOT NULL DEFAULT 0, hsn_sac TEXT);
CREATE TABLE ip_admissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_number TEXT NOT NULL UNIQUE,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      admission_doctor_id INTEGER REFERENCES doctors(id),
      admitted_at TEXT NOT NULL DEFAULT (datetime('now')),
      discharged_at TEXT,
      bed_number TEXT,
      ward TEXT,
      admission_notes TEXT,
      discharge_summary TEXT,
      status TEXT NOT NULL DEFAULT 'admitted'
    , discharge_summary_json TEXT, bed_id INTEGER REFERENCES beds(id), ward_id INTEGER REFERENCES wards(id), admission_type TEXT NOT NULL DEFAULT 'planned', provisional_diagnosis TEXT, attendant_name TEXT, attendant_phone TEXT, attendant_relation TEXT, is_mlc INTEGER NOT NULL DEFAULT 0, outcome TEXT, outcome_notes TEXT, death_at TEXT, death_cause TEXT, referred_to TEXT, risk_explained_by TEXT, bill_id INTEGER REFERENCES bills(id), discharge_diagnosis TEXT, condition_at_discharge TEXT, treatment_given TEXT, investigation_findings TEXT, operative_notes TEXT, discharge_medications_json TEXT, followup_plan TEXT, discharge_doctor_id INTEGER REFERENCES doctors(id), discharge_status TEXT NOT NULL DEFAULT 'none', discharge_requested_at TEXT, discharge_requested_by TEXT, discharge_approved_at TEXT, discharge_approved_by TEXT, discharge_override_reason TEXT);
CREATE TABLE patient_allergies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      allergen TEXT NOT NULL,
      reaction TEXT,
      severity TEXT,
      noted_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE patient_conditions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      condition TEXT NOT NULL,
      since TEXT,
      notes TEXT,
      is_active INTEGER DEFAULT 1
    );
CREATE TABLE patient_family_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      relation TEXT NOT NULL,
      condition TEXT NOT NULL,
      notes TEXT
    );
CREATE TABLE patient_immunizations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      vaccine TEXT NOT NULL,
      given_at TEXT,
      dose TEXT,
      notes TEXT
    );
CREATE TABLE patient_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      file_name TEXT NOT NULL,
      file_type TEXT,
      file_path TEXT NOT NULL,
      size_bytes INTEGER,
      note TEXT,
      uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE drug_master (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      generic_name TEXT,
      manufacturer TEXT,
      form TEXT,
      strength TEXT,
      pack_size INTEGER,
      schedule TEXT NOT NULL DEFAULT 'OTC' CHECK (schedule IN ('H','H1','G','X','OTC')),
      hsn_code TEXT,
      gst_rate REAL NOT NULL DEFAULT 12,
      default_mrp REAL NOT NULL DEFAULT 0,
      low_stock_threshold INTEGER NOT NULL DEFAULT 10,
      barcode TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wholesalers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      contact_person TEXT,
      phone TEXT,
      email TEXT,
      address TEXT,
      drug_license_no TEXT NOT NULL,
      gstin TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE purchase_invoices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_number TEXT NOT NULL,
      wholesaler_id INTEGER NOT NULL REFERENCES wholesalers(id) ON DELETE RESTRICT,
      invoice_date TEXT NOT NULL,
      received_date TEXT NOT NULL DEFAULT (date('now')),
      subtotal REAL NOT NULL DEFAULT 0,
      cgst REAL NOT NULL DEFAULT 0,
      sgst REAL NOT NULL DEFAULT 0,
      igst REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      payment_mode TEXT,
      payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('paid','unpaid','partial')),
      scan_path TEXT,
      ocr_job_id INTEGER,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (wholesaler_id, invoice_number)
    );
CREATE TABLE purchase_invoice_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_id INTEGER NOT NULL REFERENCES purchase_invoices(id) ON DELETE CASCADE,
      drug_master_id INTEGER NOT NULL REFERENCES drug_master(id) ON DELETE RESTRICT,
      batch_no TEXT NOT NULL,
      expiry TEXT NOT NULL,
      qty_received INTEGER NOT NULL,
      pack_qty INTEGER,
      free_qty INTEGER NOT NULL DEFAULT 0,
      purchase_price REAL NOT NULL,
      mrp REAL NOT NULL,
      gst_rate REAL NOT NULL DEFAULT 12,
      manufacturer_license_no TEXT,
      line_total REAL NOT NULL DEFAULT 0
    , manufacture_date TEXT);
CREATE TABLE drug_stock_batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      drug_master_id INTEGER NOT NULL REFERENCES drug_master(id) ON DELETE RESTRICT,
      purchase_item_id INTEGER REFERENCES purchase_invoice_items(id) ON DELETE SET NULL,
      batch_no TEXT NOT NULL,
      expiry TEXT NOT NULL,
      qty_received INTEGER NOT NULL,
      qty_remaining INTEGER NOT NULL,
      purchase_price REAL,
      mrp REAL NOT NULL DEFAULT 0,
      manufacturer_license_no TEXT,
      received_at TEXT NOT NULL DEFAULT (date('now')),
      is_active INTEGER NOT NULL DEFAULT 1, manufacture_date TEXT,
      UNIQUE (drug_master_id, batch_no)
    );
CREATE TABLE dispensing_register (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_item_id INTEGER NOT NULL REFERENCES pharmacy_sale_items(id) ON DELETE RESTRICT,
      sale_id INTEGER NOT NULL REFERENCES pharmacy_sales(id) ON DELETE RESTRICT,
      patient_id INTEGER REFERENCES patients(id),
      doctor_id INTEGER REFERENCES doctors(id),
      drug_master_id INTEGER NOT NULL REFERENCES drug_master(id),
      batch_id INTEGER NOT NULL REFERENCES drug_stock_batches(id),
      batch_no TEXT NOT NULL,
      expiry TEXT NOT NULL,
      schedule TEXT NOT NULL,
      qty INTEGER NOT NULL,
      rate REAL NOT NULL,
      rx_reference TEXT,
      dispensed_at TEXT NOT NULL DEFAULT (datetime('now')),
      dispensed_by TEXT
    );
CREATE TABLE counters (
      scope      TEXT PRIMARY KEY,
      next_value INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wards (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      name            TEXT NOT NULL UNIQUE,
      ward_type       TEXT NOT NULL DEFAULT 'general',
      per_day_rate    REAL NOT NULL DEFAULT 0,
      nursing_per_day REAL NOT NULL DEFAULT 0,
      colour          TEXT,
      sort_order      INTEGER NOT NULL DEFAULT 0,
      is_active       INTEGER NOT NULL DEFAULT 1,
      created_at      TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE beds (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      ward_id     INTEGER NOT NULL REFERENCES wards(id) ON DELETE CASCADE,
      bed_number  TEXT NOT NULL,
      status      TEXT NOT NULL DEFAULT 'free'
                    CHECK (status IN ('free','occupied','reserved','cleaning','blocked')),
      notes       TEXT,
      is_active   INTEGER NOT NULL DEFAULT 1,
      created_at  TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (ward_id, bed_number)
    );
CREATE TABLE bed_transfers (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id  INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      from_bed_id   INTEGER REFERENCES beds(id),
      to_bed_id     INTEGER NOT NULL REFERENCES beds(id),
      reason        TEXT,
      transferred_at TEXT NOT NULL DEFAULT (datetime('now')),
      transferred_by TEXT
    );
CREATE TABLE ip_progress_notes (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      doctor_id    INTEGER REFERENCES doctors(id),
      note         TEXT NOT NULL,
      noted_at     TEXT NOT NULL DEFAULT (datetime('now')),
      recorded_by  TEXT
    );
CREATE TABLE ip_vitals (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      temperature  REAL,
      pulse        INTEGER,
      respiration  INTEGER,
      bp_systolic  INTEGER,
      bp_diastolic INTEGER,
      spo2         INTEGER,
      pain_score   INTEGER,
      notes        TEXT,
      recorded_at  TEXT NOT NULL DEFAULT (datetime('now')),
      recorded_by  TEXT
    );
CREATE TABLE ip_medication_orders (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id   INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      drug_master_id INTEGER REFERENCES drug_master(id),
      drug_name      TEXT NOT NULL,
      dose           TEXT,
      route          TEXT,
      frequency      TEXT,
      instructions   TEXT,
      start_at       TEXT NOT NULL DEFAULT (datetime('now')),
      stop_at        TEXT,
      status         TEXT NOT NULL DEFAULT 'active'
                       CHECK (status IN ('active','stopped','completed')),
      ordered_by_doctor_id INTEGER REFERENCES doctors(id),
      created_at     TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE ip_medication_admin (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id      INTEGER NOT NULL REFERENCES ip_medication_orders(id) ON DELETE CASCADE,
      admission_id  INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      status        TEXT NOT NULL DEFAULT 'given'
                      CHECK (status IN ('given','refused','omitted','held')),
      reason        TEXT,
      qty           REAL NOT NULL DEFAULT 0,
      batch_id      INTEGER REFERENCES drug_stock_batches(id),
      bill_item_id  INTEGER,
      administered_at TEXT NOT NULL DEFAULT (datetime('now')),
      administered_by TEXT
    );
CREATE TABLE ip_intake_output (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      kind         TEXT NOT NULL CHECK (kind IN ('intake','output')),
      route        TEXT,
      volume_ml    REAL NOT NULL DEFAULT 0,
      notes        TEXT,
      recorded_at  TEXT NOT NULL DEFAULT (datetime('now')),
      recorded_by  TEXT
    );
CREATE TABLE ip_nursing_notes (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      note         TEXT NOT NULL,
      shift        TEXT,
      noted_at     TEXT NOT NULL DEFAULT (datetime('now')),
      recorded_by  TEXT,
      countersigned_by TEXT,
      countersigned_at TEXT
    );
CREATE TABLE ip_diet_orders (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      diet_type    TEXT NOT NULL,
      instructions TEXT,
      start_at     TEXT NOT NULL DEFAULT (datetime('now')),
      stop_at      TEXT,
      ordered_by   TEXT
    );
CREATE TABLE ip_cross_consultations (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      doctor_id    INTEGER NOT NULL REFERENCES doctors(id),
      reason       TEXT,
      status       TEXT NOT NULL DEFAULT 'requested'
                     CHECK (status IN ('requested','seen','declined')),
      opinion      TEXT,
      requested_at TEXT NOT NULL DEFAULT (datetime('now')),
      responded_at TEXT
    );
CREATE TABLE mlc_register (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id    INTEGER REFERENCES ip_admissions(id) ON DELETE SET NULL,
      patient_id      INTEGER NOT NULL REFERENCES patients(id),
      mlc_number      TEXT,
      police_station  TEXT,
      intimated_at    TEXT,
      intimated_by    TEXT,
      brought_by      TEXT,
      brought_by_phone TEXT,
      incident_type   TEXT,
      incident_at     TEXT,
      incident_place  TEXT,
      injury_description TEXT,
      notes           TEXT,
      created_at      TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE mlc_correspondence (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      mlc_id      INTEGER NOT NULL REFERENCES mlc_register(id) ON DELETE CASCADE,
      direction   TEXT NOT NULL CHECK (direction IN ('sent','received')),
      summary     TEXT NOT NULL,
      reference_no TEXT,
      occurred_at TEXT NOT NULL DEFAULT (datetime('now')),
      recorded_by TEXT
    );
CREATE TABLE body_release (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_id  INTEGER NOT NULL REFERENCES ip_admissions(id) ON DELETE CASCADE,
      released_to   TEXT NOT NULL,
      relation      TEXT,
      id_proof_type TEXT,
      id_proof_no   TEXT,
      contact_phone TEXT,
      released_at   TEXT NOT NULL DEFAULT (datetime('now')),
      released_by   TEXT,
      notes         TEXT
    );
CREATE TABLE charge_heads (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      name         TEXT NOT NULL,
      category     TEXT NOT NULL DEFAULT 'other',
      colour       TEXT,
      default_rate REAL NOT NULL DEFAULT 0,
      hsn_sac      TEXT,
      gst_rate     REAL NOT NULL DEFAULT 0,
      is_taxable   INTEGER NOT NULL DEFAULT 0,
      applies_to   TEXT NOT NULL DEFAULT 'both'
                     CHECK (applies_to IN ('opd','ipd','both')),
      sort_order   INTEGER NOT NULL DEFAULT 0,
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (name, category)
    );
CREATE TABLE bill_items (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_id        INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
      charge_head_id INTEGER REFERENCES charge_heads(id),
      description    TEXT NOT NULL,
      qty            REAL NOT NULL DEFAULT 1,
      rate           REAL NOT NULL DEFAULT 0,
      amount         REAL NOT NULL DEFAULT 0,
      hsn_sac        TEXT,
      gst_rate       REAL NOT NULL DEFAULT 0,
      is_taxable     INTEGER NOT NULL DEFAULT 0,
      cgst           REAL NOT NULL DEFAULT 0,
      sgst           REAL NOT NULL DEFAULT 0,
      -- Where the line came from, so a charge can be traced back and so
      -- auto-accrual does not post the same day's bed charge twice.
      source         TEXT NOT NULL DEFAULT 'manual',
      source_ref_id  INTEGER,
      accrual_date   TEXT,
      created_at     TEXT NOT NULL DEFAULT (datetime('now')),
      created_by     TEXT
    );
CREATE TABLE bill_payments (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_id      INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
      amount       REAL NOT NULL,
      payment_mode TEXT NOT NULL,
      reference    TEXT,
      received_at  TEXT NOT NULL DEFAULT (datetime('now')),
      received_by  TEXT,
      notes        TEXT
    );
CREATE TABLE advances (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id    INTEGER NOT NULL REFERENCES patients(id),
      admission_id  INTEGER REFERENCES ip_admissions(id) ON DELETE SET NULL,
      receipt_no    TEXT,
      amount        REAL NOT NULL,
      payment_mode  TEXT NOT NULL,
      received_at   TEXT NOT NULL DEFAULT (datetime('now')),
      received_by   TEXT,
      adjusted_amount REAL NOT NULL DEFAULT 0,
      refunded_amount REAL NOT NULL DEFAULT 0,
      refunded_at   TEXT,
      refunded_by   TEXT,
      refund_reason TEXT,
      notes         TEXT
    );
CREATE TABLE tpa_master (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      name          TEXT NOT NULL UNIQUE,
      code          TEXT,
      contact_person TEXT,
      phone         TEXT,
      email         TEXT,
      address       TEXT,
      notes         TEXT,
      is_active     INTEGER NOT NULL DEFAULT 1,
      created_at    TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE tpa_claims (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      tpa_id         INTEGER NOT NULL REFERENCES tpa_master(id),
      patient_id     INTEGER NOT NULL REFERENCES patients(id),
      admission_id   INTEGER REFERENCES ip_admissions(id) ON DELETE SET NULL,
      bill_id        INTEGER REFERENCES bills(id) ON DELETE SET NULL,
      policy_no      TEXT,
      insurer_name   TEXT,
      preauth_no     TEXT,
      preauth_amount REAL NOT NULL DEFAULT 0,
      preauth_status TEXT NOT NULL DEFAULT 'pending'
                       CHECK (preauth_status IN ('pending','approved','rejected','not_required')),
      claimed_amount REAL NOT NULL DEFAULT 0,
      approved_amount REAL NOT NULL DEFAULT 0,
      settled_amount REAL NOT NULL DEFAULT 0,
      copay_amount   REAL NOT NULL DEFAULT 0,
      status         TEXT NOT NULL DEFAULT 'draft'
                       CHECK (status IN ('draft','preauth_sent','preauth_approved','submitted','queried','approved','settled','rejected','closed')),
      submitted_at   TEXT,
      settled_at     TEXT,
      notes          TEXT,
      created_at     TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE discharge_templates (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      name         TEXT NOT NULL,
      department   TEXT,
      doctor_id    INTEGER REFERENCES doctors(id) ON DELETE SET NULL,
      content_json TEXT NOT NULL DEFAULT '{}',
      is_active    INTEGER NOT NULL DEFAULT 1,
      sort_order   INTEGER NOT NULL DEFAULT 0,
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE print_jobs (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      kind         TEXT NOT NULL,
      title        TEXT NOT NULL,
      patient_id   INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      patient_name TEXT,
      payload_json TEXT NOT NULL DEFAULT '{}',
      status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','printed','cancelled')),
      created_by   TEXT,
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      printed_by   TEXT,
      printed_at   TEXT
    );
CREATE TABLE admission_requests (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id    INTEGER NOT NULL REFERENCES patients(id),
      doctor_id     INTEGER REFERENCES doctors(id),
      requested_by  TEXT,
      provisional_diagnosis TEXT,
      suggested_ward_id INTEGER REFERENCES wards(id),
      urgency       TEXT NOT NULL DEFAULT 'routine' CHECK (urgency IN ('routine','urgent','emergency')),
      notes         TEXT,
      status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
      requested_at  TEXT NOT NULL DEFAULT (datetime('now')),
      decided_at    TEXT,
      decided_by    TEXT,
      decision_note TEXT,
      admission_id  INTEGER REFERENCES ip_admissions(id)
    );
CREATE TABLE peds_growth_measurements (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id   INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      measured_on  TEXT NOT NULL DEFAULT (date('now')),
      age_days     INTEGER,
      weight_kg    REAL,
      height_cm    REAL,
      head_circ_cm REAL,
      bmi          REAL,
      wfa_z REAL, lhfa_z REAL, hcfa_z REAL, bfa_z REAL,
      wfa_c REAL, lhfa_c REAL, hcfa_c REAL, bfa_c REAL,
      notes        TEXT,
      recorded_by  TEXT,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE peds_vaccine_records (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id   INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      vaccine      TEXT NOT NULL,
      schedule_age TEXT,
      due_date     TEXT,
      given_date   TEXT,
      status       TEXT NOT NULL DEFAULT 'due' CHECK (status IN ('due','given','overdue','skipped')),
      dose         TEXT,
      route        TEXT,
      site         TEXT,
      brand        TEXT,
      batch_no     TEXT,
      notes        TEXT,
      recorded_by  TEXT,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE tpa_claim_events (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      claim_id   INTEGER NOT NULL REFERENCES tpa_claims(id) ON DELETE CASCADE,
      event      TEXT NOT NULL,
      detail     TEXT,
      amount     REAL,
      occurred_at TEXT NOT NULL DEFAULT (datetime('now')),
      recorded_by TEXT
    );
CREATE TABLE "bills" (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_number TEXT NOT NULL UNIQUE,
      appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
      patient_id INTEGER REFERENCES patients(id),
      items_json TEXT NOT NULL,
      subtotal REAL NOT NULL,
      discount REAL NOT NULL DEFAULT 0,
      discount_type TEXT NOT NULL DEFAULT 'flat',
      total REAL NOT NULL,
      payment_mode TEXT NOT NULL,
      paid_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , is_free_followup INTEGER NOT NULL DEFAULT 0, followup_parent_appt_id INTEGER REFERENCES appointments(id), is_relaxed_followup INTEGER NOT NULL DEFAULT 0, doctor_id INTEGER REFERENCES doctors(id), notes TEXT, bill_kind TEXT NOT NULL DEFAULT 'opd', admission_id INTEGER REFERENCES ip_admissions(id), status TEXT NOT NULL DEFAULT 'paid', bill_type TEXT NOT NULL DEFAULT 'opd_consult', taxable_total REAL NOT NULL DEFAULT 0, exempt_total REAL NOT NULL DEFAULT 0, cgst_total REAL NOT NULL DEFAULT 0, sgst_total REAL NOT NULL DEFAULT 0, round_off REAL NOT NULL DEFAULT 0, amount_paid REAL NOT NULL DEFAULT 0, advance_adjusted REAL NOT NULL DEFAULT 0, discount_reason TEXT, discount_by TEXT, cancelled_at TEXT, cancelled_by TEXT, cancel_reason TEXT, is_tax_invoice INTEGER NOT NULL DEFAULT 0, tpa_claim_id INTEGER REFERENCES tpa_claims(id), finalized_at TEXT, finalized_by TEXT, lab_order_id INTEGER REFERENCES lab_orders(id), radiology_order_id INTEGER REFERENCES radiology_orders(id));
CREATE TABLE wa_accounts (
      id                  INTEGER PRIMARY KEY AUTOINCREMENT,
      phone_number_id     TEXT NOT NULL UNIQUE,
      waba_id             TEXT NOT NULL,
      display_name        TEXT,
      phone_number        TEXT,
      access_token_enc    TEXT NOT NULL,
      webhook_verify_token TEXT NOT NULL,
      status              TEXT NOT NULL DEFAULT 'disconnected',
      last_health_check   TEXT,
      created_at          TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wa_templates (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id   INTEGER NOT NULL REFERENCES wa_accounts(id) ON DELETE CASCADE,
      name         TEXT NOT NULL,
      category     TEXT NOT NULL DEFAULT 'UTILITY',
      language     TEXT NOT NULL DEFAULT 'en',
      status       TEXT NOT NULL DEFAULT 'PENDING',
      components   TEXT NOT NULL DEFAULT '[]',
      meta_id      TEXT,
      use_case     TEXT,
      is_active    INTEGER NOT NULL DEFAULT 1,
      created_at   TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at   TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(account_id, name)
    );
CREATE TABLE wa_automation_rules (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id     INTEGER NOT NULL REFERENCES wa_accounts(id) ON DELETE CASCADE,
      trigger        TEXT NOT NULL,
      template_name  TEXT NOT NULL,
      is_enabled     INTEGER NOT NULL DEFAULT 1,
      delay_minutes  INTEGER NOT NULL DEFAULT 0,
      extra_config   TEXT,
      created_at     TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(account_id, trigger)
    );
CREATE TABLE wa_message_queue (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id     INTEGER NOT NULL REFERENCES wa_accounts(id) ON DELETE CASCADE,
      to_phone       TEXT NOT NULL,
      patient_id     INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
      template_name  TEXT NOT NULL,
      template_vars  TEXT,
      status         TEXT NOT NULL DEFAULT 'pending',
      attempts       INTEGER NOT NULL DEFAULT 0,
      last_error     TEXT,
      scheduled_at   TEXT NOT NULL DEFAULT (datetime('now')),
      sent_at        TEXT,
      created_at     TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wa_conversations (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id      INTEGER NOT NULL REFERENCES wa_accounts(id) ON DELETE CASCADE,
      patient_id      INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      phone           TEXT NOT NULL,
      status          TEXT NOT NULL DEFAULT 'open',
      last_message_at TEXT,
      assigned_to     INTEGER REFERENCES users(id) ON DELETE SET NULL,
      created_at      TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(account_id, phone)
    );
CREATE TABLE wa_messages (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id      INTEGER NOT NULL REFERENCES wa_accounts(id) ON DELETE CASCADE,
      wam_id          TEXT UNIQUE,
      conversation_id INTEGER REFERENCES wa_conversations(id) ON DELETE SET NULL,
      patient_id      INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      direction       TEXT NOT NULL DEFAULT 'outbound',
      message_type    TEXT NOT NULL DEFAULT 'template',
      content         TEXT NOT NULL DEFAULT '{}',
      status          TEXT NOT NULL DEFAULT 'sent',
      timestamp       TEXT NOT NULL DEFAULT (datetime('now')),
      created_at      TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wa_webhook_events (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id  INTEGER REFERENCES wa_accounts(id) ON DELETE SET NULL,
      event_type  TEXT NOT NULL,
      payload     TEXT NOT NULL,
      processed   INTEGER NOT NULL DEFAULT 0,
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wa_campaigns (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id     INTEGER NOT NULL REFERENCES wa_accounts(id) ON DELETE CASCADE,
      name           TEXT NOT NULL,
      template_name  TEXT NOT NULL,
      template_vars  TEXT,
      segment        TEXT NOT NULL DEFAULT 'all',
      segment_config TEXT,
      status         TEXT NOT NULL DEFAULT 'draft',
      total_count    INTEGER NOT NULL DEFAULT 0,
      sent_count     INTEGER NOT NULL DEFAULT 0,
      failed_count   INTEGER NOT NULL DEFAULT 0,
      scheduled_at   TEXT,
      started_at     TEXT,
      completed_at   TEXT,
      created_at     TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at     TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wa_campaign_recipients (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id  INTEGER NOT NULL REFERENCES wa_campaigns(id) ON DELETE CASCADE,
      patient_id   INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      phone        TEXT NOT NULL,
      patient_name TEXT,
      status       TEXT NOT NULL DEFAULT 'pending',
      wam_id       TEXT,
      error        TEXT,
      sent_at      TEXT,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE referring_doctors (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    qualification TEXT,
    place         TEXT,
    phone         TEXT,
    is_active     INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );
CREATE TABLE radiology_tests (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT NOT NULL,
      modality   TEXT NOT NULL DEFAULT 'other',
      price      REAL NOT NULL DEFAULT 0,
      is_active  INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE radiology_orders (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number   TEXT NOT NULL UNIQUE,
      appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
      patient_id     INTEGER NOT NULL REFERENCES patients(id),
      doctor_id      INTEGER REFERENCES doctors(id),
      referred_by    TEXT,
      clinical_info  TEXT,
      status         TEXT NOT NULL DEFAULT 'ordered',
      ordered_at     TEXT NOT NULL DEFAULT (datetime('now')),
      performed_at   TEXT,
      reported_at    TEXT,
      reported_by    TEXT,
      notes          TEXT
    );
CREATE TABLE radiology_order_items (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id    INTEGER NOT NULL REFERENCES radiology_orders(id) ON DELETE CASCADE,
      test_id     INTEGER REFERENCES radiology_tests(id),
      test_name   TEXT NOT NULL,
      modality    TEXT,
      price       REAL NOT NULL DEFAULT 0,
      findings    TEXT,
      impression  TEXT,
      is_abnormal INTEGER NOT NULL DEFAULT 0
    );
INSERT INTO "schema_meta" ("key","value") VALUES ('version','4');
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (1,'LEG-initial-1','Patinitialx1','Legacy','1984-03-01','F','9746000001',NULL,'Old Market Road','B+','2026-10-21 14:20:11',NULL,NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (2,'LEG-initial-2','Patinitialx2','Legacy','1984-03-02','M','9746000002',NULL,'Old Market Road','B+','2026-10-21 14:20:11',NULL,NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (3,'LEG-v030-1','Patv030x1','Legacy','1984-03-01','F','9265000001',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (4,'LEG-v030-2','Patv030x2','Legacy','1984-03-02','M','9265000002',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (5,'LEG-v040-1','Patv040x1','Legacy','1984-03-01','F','9266000001',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (6,'LEG-v040-2','Patv040x2','Legacy','1984-03-02','M','9266000002',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (7,'LEG-v069-1','Patv069x1','Legacy','1984-03-01','F','9277000001',NULL,'Old Market Road','B+','2026-10-21 14:20:13','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (8,'LEG-v069-2','Patv069x2','Legacy','1984-03-02','M','9277000002',NULL,'Old Market Road','B+','2026-10-21 14:20:13','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (9,'LEG-v0614-1','Patv0614x1','Legacy','1984-03-01','F','9321000001',NULL,'Old Market Road','B+','2026-10-21 14:20:14','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (10,'LEG-v0614-2','Patv0614x2','Legacy','1984-03-02','M','9321000002',NULL,'Old Market Road','B+','2026-10-21 14:20:14','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (11,'LEG-v070-1','Patv070x1','Legacy','1984-03-01','F','9269000001',NULL,'Old Market Road','B+','2026-10-21 14:20:14','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (12,'LEG-v070-2','Patv070x2','Legacy','1984-03-02','M','9269000002',NULL,'Old Market Road','B+','2026-10-21 14:20:14','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id","template_id_2","template_id_3","template_slot_names") VALUES (1,'Dr. Legacy initial','General',NULL,NULL,NULL,1,300,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id","template_id_2","template_id_3","template_slot_names") VALUES (2,'Dr. Legacy v030','General',NULL,NULL,NULL,1,300,NULL,'MBBS','REG-v030',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id","template_id_2","template_id_3","template_slot_names") VALUES (3,'Dr. Legacy v040','General',NULL,NULL,NULL,1,300,NULL,'MBBS','REG-v040',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id","template_id_2","template_id_3","template_slot_names") VALUES (4,'Dr. Legacy v069','General',NULL,NULL,NULL,1,300,NULL,'MBBS','REG-v069',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id","template_id_2","template_id_3","template_slot_names") VALUES (5,'Dr. Legacy v0614','General',NULL,NULL,NULL,1,300,NULL,'MBBS','REG-v0614',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id","template_id_2","template_id_3","template_slot_names") VALUES (6,'Dr. Legacy v070','General',NULL,NULL,NULL,1,300,NULL,'MBBS','REG-v070',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (1,1,1,'2026-04-01','10:30',1,'completed','legacy visit initial','2026-10-21 14:20:11',NULL,1,1,'LEG-initial-1/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (2,2,1,'2026-04-02','11:30',2,'completed','legacy visit initial','2026-10-21 14:20:11',NULL,1,1,'LEG-initial-2/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (3,3,2,'2026-04-01','10:30',1,'completed','legacy visit v030','2026-10-21 14:20:12',NULL,1,1,'LEG-v030-1/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (4,4,2,'2026-04-02','11:30',2,'completed','legacy visit v030','2026-10-21 14:20:12',NULL,1,1,'LEG-v030-2/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (5,5,3,'2026-04-01','10:30',1,'completed','legacy visit v040','2026-10-21 14:20:12',NULL,1,1,'LEG-v040-1/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (6,6,3,'2026-04-02','11:30',2,'completed','legacy visit v040','2026-10-21 14:20:12',NULL,1,1,'LEG-v040-2/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (7,7,4,'2026-04-01','10:30',1,'completed','legacy visit v069','2026-10-21 14:20:13',NULL,1,1,'LEG-v069-1/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (8,8,4,'2026-04-02','11:30',2,'completed','legacy visit v069','2026-10-21 14:20:13',NULL,1,1,'LEG-v069-2/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (9,9,5,'2026-04-01','10:30',1,'completed','legacy visit v0614','2026-10-21 14:20:14',NULL,1,1,'LEG-v0614-1/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (10,10,5,'2026-04-02','11:30',2,'completed','legacy visit v0614','2026-10-21 14:20:14',NULL,1,1,'LEG-v0614-2/V1',NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (11,11,6,'2026-04-01','10:30',1,'completed','legacy visit v070','2026-10-21 14:20:14',NULL,1,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version","visit_number","visit_id","patient_group","procedure_tags","referred_by") VALUES (12,12,6,'2026-04-02','11:30',2,'completed','legacy visit v070','2026-10-21 14:20:14',NULL,1,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "settings" ("key","value") VALUES ('clinic_name','Legacy Clinic v070');
INSERT INTO "settings" ("key","value") VALUES ('clinic_phone','9000011111');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_initial','kept');
INSERT INTO "settings" ("key","value") VALUES ('clinic_address','1st Floor, Arihant Plaza, Rotary Circle, Gadag - 582 101');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_v030','kept');
INSERT INTO "settings" ("key","value") VALUES ('followup_enabled','true');
INSERT INTO "settings" ("key","value") VALUES ('followup_window_days','7');
INSERT INTO "settings" ("key","value") VALUES ('followup_free_visits','2');
INSERT INTO "settings" ("key","value") VALUES ('followup_grace_days','2');
INSERT INTO "settings" ("key","value") VALUES ('registration_fee_enabled','true');
INSERT INTO "settings" ("key","value") VALUES ('registration_fee_amount','100');
INSERT INTO "settings" ("key","value") VALUES ('registration_fee_default_timing','ask');
INSERT INTO "settings" ("key","value") VALUES ('misc_services','Procedure,Vaccination,Nebulization,Wound Dressing,Injection,Suture / Stitches,IV Fluids,Other');
INSERT INTO "settings" ("key","value") VALUES ('network_mode','local');
INSERT INTO "settings" ("key","value") VALUES ('network_listen_port','4321');
INSERT INTO "settings" ("key","value") VALUES ('network_server_url','');
INSERT INTO "settings" ("key","value") VALUES ('network_secret','');
INSERT INTO "settings" ("key","value") VALUES ('station_name','');
INSERT INTO "settings" ("key","value") VALUES ('slip_templates','[{"id":1,"name":"General","specialty_hint":"Default short layout","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":55,"printed":true},{"key":"examination","title":"Examination","type":"textarea","height_mm":60,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":60,"printed":true}]},{"id":2,"name":"General Medicine","specialty_hint":"Full medicine workup — past / personal / family / systemic exam","sections":[{"key":"history","title":"Chief Complaints","type":"textarea","height_mm":35,"placeholder":"Presenting complaints with onset, duration, progression","printed":true},{"key":"past_history","title":"Past History","type":"textarea","height_mm":18,"placeholder":"DM · HTN · TB · IHD · Surgeries · Allergies","printed":true},{"key":"personal_history","title":"Personal History","type":"textarea","height_mm":18,"placeholder":"Diet · Sleep · Bowel · Bladder · Addictions (smoking / alcohol / tobacco)","printed":true},{"key":"family_history","title":"Family History","type":"textarea","height_mm":14,"placeholder":"Heritable / chronic illnesses in immediate family","printed":true},{"key":"general_exam","title":"General Examination","type":"textarea","height_mm":22,"placeholder":"Pallor · Icterus · Cyanosis · Clubbing · Lymphadenopathy · Edema","printed":true},{"key":"examination","title":"Systemic Examination (CVS · RS · P/A · CNS)","type":"textarea","height_mm":35,"printed":true},{"key":"impression","title":"Provisional Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":3,"name":"OBG","specialty_hint":"Obstetrics & Gynaecology","sections":[{"key":"lmp","title":"LMP (Last Menstrual Period)","type":"date","printed":true},{"key":"edd","title":"EDD (Expected Date of Delivery)","type":"date","printed":true},{"key":"parity","title":"G / P / A / L","type":"singleline","height_mm":8,"placeholder":"e.g. G2 P1 A0 L1","printed":true},{"key":"gestational_age","title":"Gestational Age","type":"singleline","height_mm":8,"placeholder":"e.g. 28 wks 3 days","printed":true},{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":40,"printed":true},{"key":"examination","title":"P/A & P/V Examination","type":"textarea","height_mm":40,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":4,"name":"Pediatrics","specialty_hint":"Children — feeding, milestones, immunization","sections":[{"key":"feeding","title":"Feeding History","type":"textarea","height_mm":18,"printed":true},{"key":"milestones","title":"Developmental Milestones","type":"textarea","height_mm":18,"printed":true},{"key":"immunization","title":"Immunization Status","type":"singleline","height_mm":8,"placeholder":"e.g. Up to date / Partial / Pending DPT-3","printed":true},{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":40,"printed":true},{"key":"examination","title":"Examination","type":"textarea","height_mm":40,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":5,"name":"Cardiology","specialty_hint":"Heart-focused workflow with NYHA, sounds, ECG","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":35,"printed":true},{"key":"exertional","title":"Exertional Capacity / NYHA Class","type":"singleline","height_mm":8,"placeholder":"e.g. NYHA II — breathless on climbing 1 flight","printed":true},{"key":"heart_sounds","title":"Heart Sounds / Murmurs","type":"textarea","height_mm":22,"placeholder":"S1 S2 normal · No added sounds · No murmur","printed":true},{"key":"ecg_findings","title":"ECG / Echo Findings","type":"textarea","height_mm":22,"printed":true},{"key":"examination","title":"Other Examination","type":"textarea","height_mm":22,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":45,"printed":true}]},{"id":6,"name":"Orthopedic","specialty_hint":"Site, ROM, deformities","sections":[{"key":"site","title":"Site / Side","type":"singleline","height_mm":8,"placeholder":"e.g. Right knee · Left shoulder","printed":true},{"key":"mechanism","title":"Mechanism of Injury","type":"textarea","height_mm":18,"placeholder":"How did the injury happen?","printed":true},{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"printed":true},{"key":"rom","title":"Range of Motion (ROM)","type":"textarea","height_mm":18,"placeholder":"Flexion / Extension / Abduction / Rotation","printed":true},{"key":"deformities","title":"Deformities / Tenderness","type":"textarea","height_mm":18,"printed":true},{"key":"examination","title":"Other Examination","type":"textarea","height_mm":22,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":40,"printed":true}]},{"id":7,"name":"ENT","specialty_hint":"Ear · Nose · Throat — otoscopy, tuning fork, nasal, throat","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":35,"placeholder":"Onset, duration, side, associated symptoms","printed":true},{"key":"otoscopy_right","title":"Otoscopy — Right Ear","type":"textarea","height_mm":18,"placeholder":"EAC · TM appearance · Cone of light · Discharge","printed":true},{"key":"otoscopy_left","title":"Otoscopy — Left Ear","type":"textarea","height_mm":18,"placeholder":"EAC · TM appearance · Cone of light · Discharge","printed":true},{"key":"hearing","title":"Hearing Assessment","type":"singleline","height_mm":8,"placeholder":"e.g. Whisper test passed · Audiometry pending","printed":true},{"key":"tuning_fork","title":"Tuning Fork Tests","type":"textarea","height_mm":14,"placeholder":"Rinne · Weber · ABC","printed":true},{"key":"nasal","title":"Nasal Examination","type":"textarea","height_mm":18,"placeholder":"Septum · Turbinates · Discharge · Polyps","printed":true},{"key":"throat","title":"Throat / Pharynx Examination","type":"textarea","height_mm":18,"placeholder":"Tonsils · Posterior pharyngeal wall · Uvula","printed":true},{"key":"examination","title":"Other Examination","type":"textarea","height_mm":18,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":40,"printed":true}]},{"id":8,"name":"Dermatology","specialty_hint":"Skin — lesion description, distribution","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"placeholder":"Onset, duration, site, spread, associated symptoms, aggravating / relieving factors","printed":true},{"key":"lesion_description","title":"Lesion Description","type":"textarea","height_mm":22,"placeholder":"Type · Size · Shape · Border · Colour · Surface · Consistency","printed":true},{"key":"distribution","title":"Distribution / Site","type":"singleline","height_mm":8,"placeholder":"e.g. Bilateral extensor surface of forearms","printed":true},{"key":"examination","title":"General & Systemic Examination","type":"textarea","height_mm":22,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":9,"name":"Ophthalmology","specialty_hint":"Eye — vision, IOP, slit-lamp, fundus","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"placeholder":"Visual disturbance, pain, redness, discharge — onset and duration","printed":true},{"key":"vision_re","title":"Vision — Right Eye (RE)","type":"singleline","height_mm":8,"placeholder":"e.g. 6/6 unaided · 6/12 with PH","printed":true},{"key":"vision_le","title":"Vision — Left Eye (LE)","type":"singleline","height_mm":8,"placeholder":"e.g. 6/6 unaided · 6/18 with PH","printed":true},{"key":"iop","title":"IOP (Intraocular Pressure)","type":"singleline","height_mm":8,"placeholder":"RE: __mmHg  LE: __mmHg","printed":true},{"key":"slit_lamp","title":"Slit-lamp Examination","type":"textarea","height_mm":22,"placeholder":"Cornea · Anterior chamber · Lens · Vitreous","printed":true},{"key":"fundus","title":"Fundus Examination","type":"textarea","height_mm":22,"placeholder":"Disc · Vessels · Macula · Periphery","printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":18,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":45,"printed":true}]},{"id":10,"name":"Neurology","specialty_hint":"Cranial nerves, motor, sensory","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":35,"placeholder":"Headache, weakness, numbness, seizures, speech, memory — onset & progression","printed":true},{"key":"cranial_nerves","title":"Cranial Nerve Examination","type":"textarea","height_mm":22,"placeholder":"CN II–XII assessment","printed":true},{"key":"motor","title":"Motor System","type":"textarea","height_mm":18,"placeholder":"Tone · Power (MRC grade) · Reflexes · Coordination","printed":true},{"key":"sensory","title":"Sensory System","type":"textarea","height_mm":18,"placeholder":"Pain · Touch · Vibration · Proprioception","printed":true},{"key":"examination","title":"Other Examination","type":"textarea","height_mm":18,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":45,"printed":true}]},{"id":11,"name":"Psychiatry","specialty_hint":"MSE — appearance, mood, thought, perception","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"placeholder":"Presenting problem, onset, duration, precipitating factors","printed":true},{"key":"mse_appearance","title":"Mental Status — Appearance & Behaviour","type":"textarea","height_mm":18,"placeholder":"Grooming · Eye contact · Psychomotor activity","printed":true},{"key":"mse_speech_mood","title":"Mental Status — Speech & Mood","type":"textarea","height_mm":18,"placeholder":"Rate · Volume · Mood (subjective) · Affect","printed":true},{"key":"mse_thought","title":"Mental Status — Thought & Perception","type":"textarea","height_mm":18,"placeholder":"Form · Content · Hallucinations · Delusions","printed":true},{"key":"sleep_appetite","title":"Sleep / Appetite","type":"singleline","height_mm":8,"placeholder":"Sleep: __hrs · Appetite: Good/Poor","printed":true},{"key":"impression","title":"Impression / Diagnosis (ICD-10)","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Plan / Prescription","type":"textarea","height_mm":45,"printed":true}]},{"id":12,"name":"Dentistry","specialty_hint":"Tooth #, procedure, radiograph — Vitals & Rx off by default","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":25,"placeholder":"Pain, sensitivity, swelling — onset, character, severity","printed":true},{"key":"tooth_no","title":"Tooth / Site","type":"singleline","height_mm":8,"placeholder":"e.g. 36 (lower left 1st molar)","printed":true},{"key":"clinical_findings","title":"Clinical Findings","type":"textarea","height_mm":22,"placeholder":"Caries · Mobility · Percussion · Gingival status","printed":true},{"key":"xray_findings","title":"X-ray / Radiograph Findings","type":"textarea","height_mm":18,"placeholder":"Periapical / OPG / CBCT findings","printed":true},{"key":"procedure","title":"Procedure Done / Planned","type":"textarea","height_mm":22,"placeholder":"Scaling · Extraction · RCT · Crown · Filling","printed":true},{"key":"impression","title":"Diagnosis","type":"textarea","height_mm":18,"printed":true},{"key":"advice","title":"Advice & Post-procedure Instructions","type":"textarea","height_mm":40,"printed":true}],"layout":{"pages":2,"logoSize":"large","headerStyle":"full","fontSize":13,"showVitals":false,"showRxTable":false,"showSignature":true,"showQrCodes":true,"showFollowupBox":true,"page1Keys":[],"page2Keys":[]}},{"id":13,"name":"Gastroenterology","specialty_hint":"Abdomen, endoscopy, colonoscopy","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":35,"placeholder":"Pain, nausea, vomiting, diarrhoea, constipation, bleeding — onset & progression","printed":true},{"key":"abdominal_exam","title":"Abdominal Examination","type":"textarea","height_mm":25,"placeholder":"Inspection · Palpation (tender quadrant, guarding, rigidity) · Percussion · Auscultation","printed":true},{"key":"endoscopy","title":"Endoscopy / Colonoscopy Findings","type":"textarea","height_mm":18,"placeholder":"Findings and biopsy notes","printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":14,"name":"Pulmonology","specialty_hint":"SpO₂, PFT, spirometry","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"placeholder":"Cough, breathlessness, wheeze, haemoptysis — onset, triggers, severity","printed":true},{"key":"spo2_trend","title":"SpO₂ / Peak Flow / 6MWT","type":"singleline","height_mm":8,"placeholder":"SpO₂ at rest: __% · Exertion: __% · PEFR: __L/min","printed":true},{"key":"spirometry","title":"Spirometry / PFT","type":"textarea","height_mm":18,"placeholder":"FEV1: __ · FVC: __ · FEV1/FVC: __ · Pattern: Obstructive/Restrictive/Mixed","printed":true},{"key":"examination","title":"Examination","type":"textarea","height_mm":25,"placeholder":"Air entry · Wheeze · Crepitations · Added sounds","printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":45,"printed":true}]},{"id":15,"name":"Urology","specialty_hint":"KUB, USG, PSA","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"placeholder":"Dysuria, frequency, haematuria, stone symptoms, retention — onset & duration","printed":true},{"key":"urine_exam","title":"Urine Examination / Culture","type":"singleline","height_mm":8,"placeholder":"Report summary or pending","printed":true},{"key":"usg_findings","title":"USG / KUB Findings","type":"textarea","height_mm":22,"placeholder":"Kidney · Ureter · Bladder — size, calculi, hydronephrosis","printed":true},{"key":"psa","title":"PSA (if applicable)","type":"singleline","height_mm":8,"placeholder":"Total PSA: __ ng/mL  Date: __","printed":true},{"key":"examination","title":"Examination","type":"textarea","height_mm":22,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":45,"printed":true}]},{"id":16,"name":"General Surgery","specialty_hint":"Pre-op / post-op — procedure, wound status","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"printed":true},{"key":"examination","title":"Examination / Local Finding","type":"textarea","height_mm":25,"placeholder":"Local: site, size, swelling, tenderness · Systemic: CVS, RS, P/A","printed":true},{"key":"investigation","title":"Investigations","type":"textarea","height_mm":18,"placeholder":"Blood workup · USG / CT / X-ray findings","printed":true},{"key":"procedure_plan","title":"Procedure / Operation Planned","type":"singleline","height_mm":8,"placeholder":"e.g. Laparoscopic cholecystectomy · Hernia repair","printed":true},{"key":"post_op_notes","title":"Post-operative Notes","type":"textarea","height_mm":22,"placeholder":"Wound status · Drains · Diet · Activity restrictions","printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":18,"printed":true},{"key":"advice","title":"Advice / Discharge Instructions","type":"textarea","height_mm":40,"printed":true}]}]');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_v040','kept');
INSERT INTO "settings" ("key","value") VALUES ('print_patient_language','kn');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_v069','kept');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_v0614','kept');
INSERT INTO "settings" ("key","value") VALUES ('radiology_catalog_migrated','1');
INSERT INTO "settings" ("key","value") VALUES ('sample_times_utc','1');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_v070','kept');
INSERT INTO "users" ("id","username","password_hash","salt","role","display_name","doctor_id","is_active","last_login_at","created_at","must_change_password") VALUES (1,'legacy_v030','not-a-real-hash-v030','','staff',NULL,NULL,1,NULL,'2026-10-21 14:20:12',0);
INSERT INTO "users" ("id","username","password_hash","salt","role","display_name","doctor_id","is_active","last_login_at","created_at","must_change_password") VALUES (2,'legacy_v040','not-a-real-hash-v040','','staff',NULL,NULL,1,NULL,'2026-10-21 14:20:12',0);
INSERT INTO "users" ("id","username","password_hash","salt","role","display_name","doctor_id","is_active","last_login_at","created_at","must_change_password") VALUES (3,'legacy_v069','not-a-real-hash-v069','','staff',NULL,NULL,1,NULL,'2026-10-21 14:20:13',0);
INSERT INTO "users" ("id","username","password_hash","salt","role","display_name","doctor_id","is_active","last_login_at","created_at","must_change_password") VALUES (4,'legacy_v0614','not-a-real-hash-v0614','','staff',NULL,NULL,1,NULL,'2026-10-21 14:20:14',0);
INSERT INTO "users" ("id","username","password_hash","salt","role","display_name","doctor_id","is_active","last_login_at","created_at","must_change_password") VALUES (5,'legacy_v070','not-a-real-hash-v070','','staff',NULL,NULL,1,NULL,'2026-10-21 14:20:14',0);
INSERT INTO "lab_tests" ("id","name","price","sample_type","ref_range","unit","is_active","category") VALUES (1,'Legacy CBC v030',250,NULL,NULL,'',1,'pathology');
INSERT INTO "lab_tests" ("id","name","price","sample_type","ref_range","unit","is_active","category") VALUES (2,'Legacy CBC v040',250,NULL,NULL,'',1,'pathology');
INSERT INTO "lab_tests" ("id","name","price","sample_type","ref_range","unit","is_active","category") VALUES (3,'Legacy CBC v069',250,NULL,NULL,'',1,'pathology');
INSERT INTO "lab_tests" ("id","name","price","sample_type","ref_range","unit","is_active","category") VALUES (4,'Legacy CBC v0614',250,NULL,NULL,'',1,'pathology');
INSERT INTO "lab_tests" ("id","name","price","sample_type","ref_range","unit","is_active","category") VALUES (5,'Legacy CBC v070',250,NULL,NULL,'',1,'pathology');
INSERT INTO "lab_orders" ("id","order_number","appointment_id","patient_id","doctor_id","status","ordered_at","collected_at","reported_at","notes") VALUES (1,'LEG-v030-LAB1',NULL,3,2,'ordered','2026-10-21 14:20:12',NULL,NULL,NULL);
INSERT INTO "lab_orders" ("id","order_number","appointment_id","patient_id","doctor_id","status","ordered_at","collected_at","reported_at","notes") VALUES (2,'LEG-v040-LAB1',NULL,5,3,'ordered','2026-10-21 14:20:12',NULL,NULL,NULL);
INSERT INTO "lab_orders" ("id","order_number","appointment_id","patient_id","doctor_id","status","ordered_at","collected_at","reported_at","notes") VALUES (3,'LEG-v069-LAB1',NULL,7,4,'ordered','2026-10-21 14:20:13',NULL,NULL,NULL);
INSERT INTO "lab_orders" ("id","order_number","appointment_id","patient_id","doctor_id","status","ordered_at","collected_at","reported_at","notes") VALUES (4,'LEG-v0614-LAB1',NULL,9,5,'ordered','2026-10-21 14:20:14',NULL,NULL,NULL);
INSERT INTO "lab_orders" ("id","order_number","appointment_id","patient_id","doctor_id","status","ordered_at","collected_at","reported_at","notes") VALUES (5,'LEG-v070-LAB1',NULL,11,6,'ordered','2026-10-21 14:20:14',NULL,NULL,NULL);
INSERT INTO "lab_order_items" ("id","lab_order_id","lab_test_id","test_name","result","unit","ref_range","is_abnormal") VALUES (1,1,1,'Legacy CBC v030','12.5','g/dL',NULL,0);
INSERT INTO "lab_order_items" ("id","lab_order_id","lab_test_id","test_name","result","unit","ref_range","is_abnormal") VALUES (2,2,2,'Legacy CBC v040','12.5','g/dL',NULL,0);
INSERT INTO "lab_order_items" ("id","lab_order_id","lab_test_id","test_name","result","unit","ref_range","is_abnormal") VALUES (3,3,3,'Legacy CBC v069','12.5','g/dL',NULL,0);
INSERT INTO "lab_order_items" ("id","lab_order_id","lab_test_id","test_name","result","unit","ref_range","is_abnormal") VALUES (4,4,4,'Legacy CBC v0614','12.5','g/dL',NULL,0);
INSERT INTO "lab_order_items" ("id","lab_order_id","lab_test_id","test_name","result","unit","ref_range","is_abnormal") VALUES (5,5,5,'Legacy CBC v070','12.5','g/dL',NULL,0);
INSERT INTO "pharmacy_sales" ("id","sale_number","patient_id","appointment_id","subtotal","discount","total","payment_mode","sold_by","created_at","taxable_total","exempt_total","cgst_total","sgst_total","is_tax_invoice") VALUES (1,'LEG-v030-S1',3,NULL,1000,0,1000,'Cash','desk','2026-10-21 14:20:12',0,0,0,0,0);
INSERT INTO "pharmacy_sales" ("id","sale_number","patient_id","appointment_id","subtotal","discount","total","payment_mode","sold_by","created_at","taxable_total","exempt_total","cgst_total","sgst_total","is_tax_invoice") VALUES (2,'LEG-v040-S1',5,NULL,1000,0,1000,'Cash','desk','2026-10-21 14:20:12',0,0,0,0,0);
INSERT INTO "pharmacy_sales" ("id","sale_number","patient_id","appointment_id","subtotal","discount","total","payment_mode","sold_by","created_at","taxable_total","exempt_total","cgst_total","sgst_total","is_tax_invoice") VALUES (3,'LEG-v069-S1',7,NULL,1000,0,1000,'Cash','desk','2026-10-21 14:20:13',0,0,0,0,0);
INSERT INTO "pharmacy_sales" ("id","sale_number","patient_id","appointment_id","subtotal","discount","total","payment_mode","sold_by","created_at","taxable_total","exempt_total","cgst_total","sgst_total","is_tax_invoice") VALUES (4,'LEG-v0614-S1',9,NULL,1000,0,1000,'Cash','desk','2026-10-21 14:20:14',0,0,0,0,0);
INSERT INTO "pharmacy_sales" ("id","sale_number","patient_id","appointment_id","subtotal","discount","total","payment_mode","sold_by","created_at","taxable_total","exempt_total","cgst_total","sgst_total","is_tax_invoice") VALUES (5,'LEG-v070-S1',11,NULL,1000,0,1000,'Cash','desk','2026-10-21 14:20:14',0,0,0,0,0);
INSERT INTO "pharmacy_sale_items" ("id","sale_id","drug_id","drug_name","qty","rate","amount","drug_master_id","batch_id","gst_amount","gst_rate","cgst","sgst","hsn_sac") VALUES (1,1,NULL,'Legacy Drug v030',10,100,1000,1,1,0,0,0,0,NULL);
INSERT INTO "pharmacy_sale_items" ("id","sale_id","drug_id","drug_name","qty","rate","amount","drug_master_id","batch_id","gst_amount","gst_rate","cgst","sgst","hsn_sac") VALUES (2,2,NULL,'Legacy Drug v040',10,100,1000,2,2,0,0,0,0,NULL);
INSERT INTO "pharmacy_sale_items" ("id","sale_id","drug_id","drug_name","qty","rate","amount","drug_master_id","batch_id","gst_amount","gst_rate","cgst","sgst","hsn_sac") VALUES (3,3,NULL,'Legacy Drug v069',10,100,1000,3,3,0,0,0,0,NULL);
INSERT INTO "pharmacy_sale_items" ("id","sale_id","drug_id","drug_name","qty","rate","amount","drug_master_id","batch_id","gst_amount","gst_rate","cgst","sgst","hsn_sac") VALUES (4,4,NULL,'Legacy Drug v0614',10,100,1000,4,4,0,0,0,0,NULL);
INSERT INTO "pharmacy_sale_items" ("id","sale_id","drug_id","drug_name","qty","rate","amount","drug_master_id","batch_id","gst_amount","gst_rate","cgst","sgst","hsn_sac") VALUES (5,5,NULL,'Legacy Drug v070',10,100,1000,5,5,0,0,0,0,NULL);
INSERT INTO "ip_admissions" ("id","admission_number","patient_id","admission_doctor_id","admitted_at","discharged_at","bed_number","ward","admission_notes","discharge_summary","status","discharge_summary_json","bed_id","ward_id","admission_type","provisional_diagnosis","attendant_name","attendant_phone","attendant_relation","is_mlc","outcome","outcome_notes","death_at","death_cause","referred_to","risk_explained_by","bill_id","discharge_diagnosis","condition_at_discharge","treatment_given","investigation_findings","operative_notes","discharge_medications_json","followup_plan","discharge_doctor_id","discharge_status","discharge_requested_at","discharge_requested_by","discharge_approved_at","discharge_approved_by","discharge_override_reason") VALUES (1,'LEG-v030-IP1',4,NULL,'2026-10-21 14:20:12',NULL,NULL,NULL,NULL,NULL,'admitted',NULL,NULL,NULL,'planned',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'none',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "ip_admissions" ("id","admission_number","patient_id","admission_doctor_id","admitted_at","discharged_at","bed_number","ward","admission_notes","discharge_summary","status","discharge_summary_json","bed_id","ward_id","admission_type","provisional_diagnosis","attendant_name","attendant_phone","attendant_relation","is_mlc","outcome","outcome_notes","death_at","death_cause","referred_to","risk_explained_by","bill_id","discharge_diagnosis","condition_at_discharge","treatment_given","investigation_findings","operative_notes","discharge_medications_json","followup_plan","discharge_doctor_id","discharge_status","discharge_requested_at","discharge_requested_by","discharge_approved_at","discharge_approved_by","discharge_override_reason") VALUES (2,'LEG-v040-IP1',6,NULL,'2026-10-21 14:20:12',NULL,NULL,NULL,NULL,NULL,'admitted',NULL,NULL,NULL,'planned',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'none',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "ip_admissions" ("id","admission_number","patient_id","admission_doctor_id","admitted_at","discharged_at","bed_number","ward","admission_notes","discharge_summary","status","discharge_summary_json","bed_id","ward_id","admission_type","provisional_diagnosis","attendant_name","attendant_phone","attendant_relation","is_mlc","outcome","outcome_notes","death_at","death_cause","referred_to","risk_explained_by","bill_id","discharge_diagnosis","condition_at_discharge","treatment_given","investigation_findings","operative_notes","discharge_medications_json","followup_plan","discharge_doctor_id","discharge_status","discharge_requested_at","discharge_requested_by","discharge_approved_at","discharge_approved_by","discharge_override_reason") VALUES (3,'LEG-v069-IP1',8,NULL,'2026-10-21 14:20:13',NULL,NULL,NULL,NULL,NULL,'admitted',NULL,NULL,NULL,'planned',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'none',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "ip_admissions" ("id","admission_number","patient_id","admission_doctor_id","admitted_at","discharged_at","bed_number","ward","admission_notes","discharge_summary","status","discharge_summary_json","bed_id","ward_id","admission_type","provisional_diagnosis","attendant_name","attendant_phone","attendant_relation","is_mlc","outcome","outcome_notes","death_at","death_cause","referred_to","risk_explained_by","bill_id","discharge_diagnosis","condition_at_discharge","treatment_given","investigation_findings","operative_notes","discharge_medications_json","followup_plan","discharge_doctor_id","discharge_status","discharge_requested_at","discharge_requested_by","discharge_approved_at","discharge_approved_by","discharge_override_reason") VALUES (4,'LEG-v0614-IP1',10,NULL,'2026-10-21 14:20:14',NULL,NULL,NULL,NULL,NULL,'admitted',NULL,NULL,NULL,'planned',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'none',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "ip_admissions" ("id","admission_number","patient_id","admission_doctor_id","admitted_at","discharged_at","bed_number","ward","admission_notes","discharge_summary","status","discharge_summary_json","bed_id","ward_id","admission_type","provisional_diagnosis","attendant_name","attendant_phone","attendant_relation","is_mlc","outcome","outcome_notes","death_at","death_cause","referred_to","risk_explained_by","bill_id","discharge_diagnosis","condition_at_discharge","treatment_given","investigation_findings","operative_notes","discharge_medications_json","followup_plan","discharge_doctor_id","discharge_status","discharge_requested_at","discharge_requested_by","discharge_approved_at","discharge_approved_by","discharge_override_reason") VALUES (5,'LEG-v070-IP1',12,NULL,'2026-10-21 14:20:14',NULL,NULL,NULL,NULL,NULL,'admitted',NULL,NULL,NULL,'planned',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,17,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'none',NULL,NULL,NULL,NULL,NULL);
INSERT INTO "drug_master" ("id","name","generic_name","manufacturer","form","strength","pack_size","schedule","hsn_code","gst_rate","default_mrp","low_stock_threshold","barcode","is_active","notes","created_at","updated_at") VALUES (1,'Legacy Drug v030',NULL,NULL,'Tablet','500mg',NULL,'OTC',NULL,12,100,10,NULL,1,NULL,'2026-10-21 14:20:12','2026-10-21 14:20:12');
INSERT INTO "drug_master" ("id","name","generic_name","manufacturer","form","strength","pack_size","schedule","hsn_code","gst_rate","default_mrp","low_stock_threshold","barcode","is_active","notes","created_at","updated_at") VALUES (2,'Legacy Drug v040',NULL,NULL,'Tablet','500mg',NULL,'OTC',NULL,12,100,10,NULL,1,NULL,'2026-10-21 14:20:12','2026-10-21 14:20:12');
INSERT INTO "drug_master" ("id","name","generic_name","manufacturer","form","strength","pack_size","schedule","hsn_code","gst_rate","default_mrp","low_stock_threshold","barcode","is_active","notes","created_at","updated_at") VALUES (3,'Legacy Drug v069',NULL,NULL,'Tablet','500mg',NULL,'OTC',NULL,12,100,10,NULL,1,NULL,'2026-10-21 14:20:13','2026-10-21 14:20:13');
INSERT INTO "drug_master" ("id","name","generic_name","manufacturer","form","strength","pack_size","schedule","hsn_code","gst_rate","default_mrp","low_stock_threshold","barcode","is_active","notes","created_at","updated_at") VALUES (4,'Legacy Drug v0614',NULL,NULL,'Tablet','500mg',NULL,'OTC',NULL,12,100,10,NULL,1,NULL,'2026-10-21 14:20:14','2026-10-21 14:20:14');
INSERT INTO "drug_master" ("id","name","generic_name","manufacturer","form","strength","pack_size","schedule","hsn_code","gst_rate","default_mrp","low_stock_threshold","barcode","is_active","notes","created_at","updated_at") VALUES (5,'Legacy Drug v070',NULL,NULL,'Tablet','500mg',NULL,'OTC',NULL,12,100,10,NULL,1,NULL,'2026-10-21 14:20:14','2026-10-21 14:20:14');
INSERT INTO "wholesalers" ("id","name","contact_person","phone","email","address","drug_license_no","gstin","is_active","notes","created_at") VALUES (1,'Legacy Supplier v030',NULL,NULL,NULL,NULL,'DL-v030',NULL,1,NULL,'2026-10-21 14:20:12');
INSERT INTO "wholesalers" ("id","name","contact_person","phone","email","address","drug_license_no","gstin","is_active","notes","created_at") VALUES (2,'Legacy Supplier v040',NULL,NULL,NULL,NULL,'DL-v040',NULL,1,NULL,'2026-10-21 14:20:12');
INSERT INTO "wholesalers" ("id","name","contact_person","phone","email","address","drug_license_no","gstin","is_active","notes","created_at") VALUES (3,'Legacy Supplier v069',NULL,NULL,NULL,NULL,'DL-v069',NULL,1,NULL,'2026-10-21 14:20:13');
INSERT INTO "wholesalers" ("id","name","contact_person","phone","email","address","drug_license_no","gstin","is_active","notes","created_at") VALUES (4,'Legacy Supplier v0614',NULL,NULL,NULL,NULL,'DL-v0614',NULL,1,NULL,'2026-10-21 14:20:14');
INSERT INTO "wholesalers" ("id","name","contact_person","phone","email","address","drug_license_no","gstin","is_active","notes","created_at") VALUES (5,'Legacy Supplier v070',NULL,NULL,NULL,NULL,'DL-v070',NULL,1,NULL,'2026-10-21 14:20:14');
INSERT INTO "purchase_invoices" ("id","invoice_number","wholesaler_id","invoice_date","received_date","subtotal","cgst","sgst","igst","discount","total","payment_mode","payment_status","scan_path","ocr_job_id","notes","created_at") VALUES (1,'LEG-v030-INV',1,'2026-04-05','2026-10-21',5000,0,0,0,0,5000,NULL,'paid',NULL,NULL,NULL,'2026-10-21 14:20:12');
INSERT INTO "purchase_invoices" ("id","invoice_number","wholesaler_id","invoice_date","received_date","subtotal","cgst","sgst","igst","discount","total","payment_mode","payment_status","scan_path","ocr_job_id","notes","created_at") VALUES (2,'LEG-v040-INV',2,'2026-04-05','2026-10-21',5000,0,0,0,0,5000,NULL,'paid',NULL,NULL,NULL,'2026-10-21 14:20:12');
INSERT INTO "purchase_invoices" ("id","invoice_number","wholesaler_id","invoice_date","received_date","subtotal","cgst","sgst","igst","discount","total","payment_mode","payment_status","scan_path","ocr_job_id","notes","created_at") VALUES (3,'LEG-v069-INV',3,'2026-04-05','2026-10-21',5000,0,0,0,0,5000,NULL,'paid',NULL,NULL,NULL,'2026-10-21 14:20:13');
INSERT INTO "purchase_invoices" ("id","invoice_number","wholesaler_id","invoice_date","received_date","subtotal","cgst","sgst","igst","discount","total","payment_mode","payment_status","scan_path","ocr_job_id","notes","created_at") VALUES (4,'LEG-v0614-INV',4,'2026-04-05','2026-10-21',5000,0,0,0,0,5000,NULL,'paid',NULL,NULL,NULL,'2026-10-21 14:20:14');
INSERT INTO "purchase_invoices" ("id","invoice_number","wholesaler_id","invoice_date","received_date","subtotal","cgst","sgst","igst","discount","total","payment_mode","payment_status","scan_path","ocr_job_id","notes","created_at") VALUES (5,'LEG-v070-INV',5,'2026-04-05','2026-10-21',5000,0,0,0,0,5000,NULL,'paid',NULL,NULL,NULL,'2026-10-21 14:20:14');
INSERT INTO "purchase_invoice_items" ("id","invoice_id","drug_master_id","batch_no","expiry","qty_received","pack_qty","free_qty","purchase_price","mrp","gst_rate","manufacturer_license_no","line_total","manufacture_date") VALUES (1,1,1,'PB-v030','2030-01-01',100,NULL,0,50,100,12,NULL,5000,NULL);
INSERT INTO "purchase_invoice_items" ("id","invoice_id","drug_master_id","batch_no","expiry","qty_received","pack_qty","free_qty","purchase_price","mrp","gst_rate","manufacturer_license_no","line_total","manufacture_date") VALUES (2,2,2,'PB-v040','2030-01-01',100,NULL,0,50,100,12,NULL,5000,NULL);
INSERT INTO "purchase_invoice_items" ("id","invoice_id","drug_master_id","batch_no","expiry","qty_received","pack_qty","free_qty","purchase_price","mrp","gst_rate","manufacturer_license_no","line_total","manufacture_date") VALUES (3,3,3,'PB-v069','2030-01-01',100,NULL,0,50,100,12,NULL,5000,NULL);
INSERT INTO "purchase_invoice_items" ("id","invoice_id","drug_master_id","batch_no","expiry","qty_received","pack_qty","free_qty","purchase_price","mrp","gst_rate","manufacturer_license_no","line_total","manufacture_date") VALUES (4,4,4,'PB-v0614','2030-01-01',100,NULL,0,50,100,12,NULL,5000,NULL);
INSERT INTO "purchase_invoice_items" ("id","invoice_id","drug_master_id","batch_no","expiry","qty_received","pack_qty","free_qty","purchase_price","mrp","gst_rate","manufacturer_license_no","line_total","manufacture_date") VALUES (5,5,5,'PB-v070','2030-01-01',100,NULL,0,50,100,12,NULL,5000,NULL);
INSERT INTO "drug_stock_batches" ("id","drug_master_id","purchase_item_id","batch_no","expiry","qty_received","qty_remaining","purchase_price","mrp","manufacturer_license_no","received_at","is_active","manufacture_date") VALUES (1,1,1,'PB-v030','2030-01-01',100,90,50,100,NULL,'2026-10-21',1,NULL);
INSERT INTO "drug_stock_batches" ("id","drug_master_id","purchase_item_id","batch_no","expiry","qty_received","qty_remaining","purchase_price","mrp","manufacturer_license_no","received_at","is_active","manufacture_date") VALUES (2,2,2,'PB-v040','2030-01-01',100,90,50,100,NULL,'2026-10-21',1,NULL);
INSERT INTO "drug_stock_batches" ("id","drug_master_id","purchase_item_id","batch_no","expiry","qty_received","qty_remaining","purchase_price","mrp","manufacturer_license_no","received_at","is_active","manufacture_date") VALUES (3,3,3,'PB-v069','2030-01-01',100,90,50,100,NULL,'2026-10-21',1,NULL);
INSERT INTO "drug_stock_batches" ("id","drug_master_id","purchase_item_id","batch_no","expiry","qty_received","qty_remaining","purchase_price","mrp","manufacturer_license_no","received_at","is_active","manufacture_date") VALUES (4,4,4,'PB-v0614','2030-01-01',100,90,50,100,NULL,'2026-10-21',1,NULL);
INSERT INTO "drug_stock_batches" ("id","drug_master_id","purchase_item_id","batch_no","expiry","qty_received","qty_remaining","purchase_price","mrp","manufacturer_license_no","received_at","is_active","manufacture_date") VALUES (5,5,5,'PB-v070','2030-01-01',100,90,50,100,NULL,'2026-10-21',1,NULL);
INSERT INTO "dispensing_register" ("id","sale_item_id","sale_id","patient_id","doctor_id","drug_master_id","batch_id","batch_no","expiry","schedule","qty","rate","rx_reference","dispensed_at","dispensed_by") VALUES (1,1,1,3,NULL,1,1,'PB-v030','2030-01-01','OTC',10,100,NULL,'2026-10-21 14:20:12',NULL);
INSERT INTO "dispensing_register" ("id","sale_item_id","sale_id","patient_id","doctor_id","drug_master_id","batch_id","batch_no","expiry","schedule","qty","rate","rx_reference","dispensed_at","dispensed_by") VALUES (2,2,2,5,NULL,2,2,'PB-v040','2030-01-01','OTC',10,100,NULL,'2026-10-21 14:20:12',NULL);
INSERT INTO "dispensing_register" ("id","sale_item_id","sale_id","patient_id","doctor_id","drug_master_id","batch_id","batch_no","expiry","schedule","qty","rate","rx_reference","dispensed_at","dispensed_by") VALUES (3,3,3,7,NULL,3,3,'PB-v069','2030-01-01','OTC',10,100,NULL,'2026-10-21 14:20:13',NULL);
INSERT INTO "dispensing_register" ("id","sale_item_id","sale_id","patient_id","doctor_id","drug_master_id","batch_id","batch_no","expiry","schedule","qty","rate","rx_reference","dispensed_at","dispensed_by") VALUES (4,4,4,9,NULL,4,4,'PB-v0614','2030-01-01','OTC',10,100,NULL,'2026-10-21 14:20:14',NULL);
INSERT INTO "dispensing_register" ("id","sale_item_id","sale_id","patient_id","doctor_id","drug_master_id","batch_id","batch_no","expiry","schedule","qty","rate","rx_reference","dispensed_at","dispensed_by") VALUES (5,5,5,11,NULL,5,5,'PB-v070','2030-01-01','OTC',10,100,NULL,'2026-10-21 14:20:14',NULL);
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:1',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:2',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:3',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:4',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:5',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:6',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:7',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:8',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:9',1,'2026-10-21 14:20:14');
INSERT INTO "counters" ("scope","next_value","updated_at") VALUES ('visit:10',1,'2026-10-21 14:20:14');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (1,'Consultation','doctor','#7c3aed',0,NULL,0,0,'both',0,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (2,'Follow-up Visit','doctor','#8b5cf6',0,NULL,0,0,'both',1,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (3,'Daily Visit Charge','doctor','#a78bfa',0,NULL,0,0,'ipd',2,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (4,'Bed Charge','bed','#2563eb',0,NULL,0,0,'ipd',3,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (5,'Nursing Charge','nursing','#0d9488',0,NULL,0,0,'ipd',4,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (6,'Procedure','procedure','#db2777',0,NULL,0,0,'both',5,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (7,'Laboratory','lab','#d97706',0,NULL,0,0,'both',6,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (8,'Pharmacy','pharmacy','#059669',0,NULL,0,0,'both',7,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (9,'Oxygen','other','#0891b2',0,NULL,0,0,'ipd',8,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (10,'Registration Fee','other','#64748b',0,NULL,0,0,'opd',9,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (11,'Admission Charge','other','#475569',0,NULL,0,0,'ipd',10,1,'2026-10-21 14:20:13');
INSERT INTO "charge_heads" ("id","name","category","colour","default_rate","hsn_sac","gst_rate","is_taxable","applies_to","sort_order","is_active","created_at") VALUES (12,'Radiology','radiology','#0891b2',0,NULL,0,0,'both',7,1,'2026-10-21 14:20:14');
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (1,1,NULL,'OPD Consultation',1,300,300,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:13',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (2,2,NULL,'OPD Consultation',1,400,400,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:13',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (3,3,NULL,'OPD Consultation',1,300,300,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:13',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (4,4,NULL,'OPD Consultation',1,400,400,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:13',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (5,6,NULL,'OPD Consultation',1,300,300,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:13',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (6,7,NULL,'OPD Consultation',1,400,400,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:13',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (7,9,NULL,'OPD Consultation',1,300,300,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:14',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (8,10,NULL,'OPD Consultation',1,400,400,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:14',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (9,12,NULL,'OPD Consultation',1,300,300,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:14',NULL);
INSERT INTO "bill_items" ("id","bill_id","charge_head_id","description","qty","rate","amount","hsn_sac","gst_rate","is_taxable","cgst","sgst","source","source_ref_id","accrual_date","created_at","created_by") VALUES (10,13,NULL,'OPD Consultation',1,400,400,NULL,0,0,0,0,'migrated',NULL,NULL,'2026-10-21 14:20:14',NULL);
INSERT INTO "bill_payments" ("id","bill_id","amount","payment_mode","reference","received_at","received_by","notes") VALUES (1,9,300,'Cash',NULL,'2026-10-21 14:20:13',NULL,NULL);
INSERT INTO "bill_payments" ("id","bill_id","amount","payment_mode","reference","received_at","received_by","notes") VALUES (2,10,150,'Cash',NULL,'2026-10-21 14:20:13',NULL,NULL);
INSERT INTO "bill_payments" ("id","bill_id","amount","payment_mode","reference","received_at","received_by","notes") VALUES (3,12,300,'Cash',NULL,'2026-10-21 14:20:14',NULL,NULL);
INSERT INTO "bill_payments" ("id","bill_id","amount","payment_mode","reference","received_at","received_by","notes") VALUES (4,13,150,'Cash',NULL,'2026-10-21 14:20:14',NULL,NULL);
INSERT INTO "bill_payments" ("id","bill_id","amount","payment_mode","reference","received_at","received_by","notes") VALUES (5,15,300,'Cash',NULL,'2026-10-21 14:20:14',NULL,NULL);
INSERT INTO "bill_payments" ("id","bill_id","amount","payment_mode","reference","received_at","received_by","notes") VALUES (6,16,150,'Cash',NULL,'2026-10-21 14:20:14',NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (1,'LEG-initial-B1',1,1,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:11',0,NULL,0,NULL,NULL,'opd',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (2,'LEG-initial-B2',2,2,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:11',0,NULL,0,NULL,NULL,'opd',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (3,'LEG-v030-B1',3,3,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (4,'LEG-v030-B2',4,4,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (5,'LEG-v030-IPD1',NULL,4,'[]',0,0,'flat',0,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (6,'LEG-v040-B1',5,5,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:12',0,NULL,0,NULL,'legacy bill v040','consultation',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (7,'LEG-v040-B2',6,6,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,'legacy bill v040','consultation',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (8,'LEG-v040-IPD1',NULL,6,'[]',0,0,'flat',0,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd',NULL,'paid','opd_consult',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (9,'LEG-v069-B1',7,7,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:13',0,NULL,0,NULL,'legacy bill v069','consultation',NULL,'paid','opd',0,0,0,0,0,300,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (10,'LEG-v069-B2',8,8,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:13',0,NULL,0,NULL,'legacy bill v069','consultation',NULL,'part_paid','opd',0,0,0,0,0,150,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (11,'LEG-v069-IPD1',NULL,8,'[]',0,0,'flat',0,'Pending',NULL,'2026-10-21 14:20:13',0,NULL,0,NULL,NULL,'opd',3,'open','ipd',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (12,'LEG-v0614-B1',9,9,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:14',0,NULL,0,NULL,'legacy bill v0614','consultation',NULL,'paid','opd',0,0,0,0,0,300,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (13,'LEG-v0614-B2',10,10,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:14',0,NULL,0,NULL,'legacy bill v0614','consultation',NULL,'part_paid','opd',0,0,0,0,0,150,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (14,'LEG-v0614-IPD1',NULL,10,'[]',0,0,'flat',0,'Pending',NULL,'2026-10-21 14:20:14',0,NULL,0,NULL,NULL,'opd',4,'open','ipd',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (15,'LEG-v070-B1',11,11,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:14',0,NULL,0,NULL,'legacy bill v070','consultation',NULL,'paid','opd',0,0,0,0,0,300,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (16,'LEG-v070-B2',12,12,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:14',0,NULL,0,NULL,'legacy bill v070','consultation',NULL,'part_paid','opd',0,0,0,0,0,150,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind","admission_id","status","bill_type","taxable_total","exempt_total","cgst_total","sgst_total","round_off","amount_paid","advance_adjusted","discount_reason","discount_by","cancelled_at","cancelled_by","cancel_reason","is_tax_invoice","tpa_claim_id","finalized_at","finalized_by","lab_order_id","radiology_order_id") VALUES (17,'LEG-v070-IPD1',NULL,12,'[]',0,0,'flat',0,'Pending',NULL,'2026-10-21 14:20:14',0,NULL,0,NULL,NULL,'opd',5,'open','ipd',0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);
DELETE FROM sqlite_sequence WHERE name='doctors';
INSERT INTO sqlite_sequence (name, seq) VALUES ('doctors', 6);
DELETE FROM sqlite_sequence WHERE name='patients';
INSERT INTO sqlite_sequence (name, seq) VALUES ('patients', 12);
DELETE FROM sqlite_sequence WHERE name='appointments';
INSERT INTO sqlite_sequence (name, seq) VALUES ('appointments', 12);
DELETE FROM sqlite_sequence WHERE name='lab_tests';
INSERT INTO sqlite_sequence (name, seq) VALUES ('lab_tests', 5);
DELETE FROM sqlite_sequence WHERE name='lab_orders';
INSERT INTO sqlite_sequence (name, seq) VALUES ('lab_orders', 5);
DELETE FROM sqlite_sequence WHERE name='lab_order_items';
INSERT INTO sqlite_sequence (name, seq) VALUES ('lab_order_items', 5);
DELETE FROM sqlite_sequence WHERE name='ip_admissions';
INSERT INTO sqlite_sequence (name, seq) VALUES ('ip_admissions', 5);
DELETE FROM sqlite_sequence WHERE name='drug_master';
INSERT INTO sqlite_sequence (name, seq) VALUES ('drug_master', 5);
DELETE FROM sqlite_sequence WHERE name='wholesalers';
INSERT INTO sqlite_sequence (name, seq) VALUES ('wholesalers', 5);
DELETE FROM sqlite_sequence WHERE name='purchase_invoices';
INSERT INTO sqlite_sequence (name, seq) VALUES ('purchase_invoices', 5);
DELETE FROM sqlite_sequence WHERE name='purchase_invoice_items';
INSERT INTO sqlite_sequence (name, seq) VALUES ('purchase_invoice_items', 5);
DELETE FROM sqlite_sequence WHERE name='drug_stock_batches';
INSERT INTO sqlite_sequence (name, seq) VALUES ('drug_stock_batches', 5);
DELETE FROM sqlite_sequence WHERE name='pharmacy_sales';
INSERT INTO sqlite_sequence (name, seq) VALUES ('pharmacy_sales', 5);
DELETE FROM sqlite_sequence WHERE name='pharmacy_sale_items';
INSERT INTO sqlite_sequence (name, seq) VALUES ('pharmacy_sale_items', 5);
DELETE FROM sqlite_sequence WHERE name='dispensing_register';
INSERT INTO sqlite_sequence (name, seq) VALUES ('dispensing_register', 5);
DELETE FROM sqlite_sequence WHERE name='users';
INSERT INTO sqlite_sequence (name, seq) VALUES ('users', 5);
DELETE FROM sqlite_sequence WHERE name='bills';
INSERT INTO sqlite_sequence (name, seq) VALUES ('bills', 17);
DELETE FROM sqlite_sequence WHERE name='bill_items';
INSERT INTO sqlite_sequence (name, seq) VALUES ('bill_items', 10);
DELETE FROM sqlite_sequence WHERE name='charge_heads';
INSERT INTO sqlite_sequence (name, seq) VALUES ('charge_heads', 12);
DELETE FROM sqlite_sequence WHERE name='bill_payments';
INSERT INTO sqlite_sequence (name, seq) VALUES ('bill_payments', 6);
CREATE INDEX idx_patients_phone ON patients(phone);
CREATE INDEX idx_patients_name ON patients(first_name, last_name);
CREATE INDEX idx_appt_date_doctor ON appointments(appointment_date, doctor_id);
CREATE INDEX idx_appt_patient ON appointments(patient_id);
CREATE INDEX idx_notif_status ON notification_log(status);
CREATE INDEX idx_consult_patient ON consultations(patient_id);
CREATE INDEX idx_audit_at ON audit_log(at);
CREATE INDEX idx_rx_appt ON prescription_items(appointment_id);
CREATE INDEX idx_lab_orders_patient ON lab_orders(patient_id);
CREATE INDEX idx_drug_name ON drug_inventory(name);
CREATE INDEX idx_ip_status ON ip_admissions(status);
CREATE INDEX idx_allergy_patient ON patient_allergies(patient_id);
CREATE INDEX idx_cond_patient ON patient_conditions(patient_id);
CREATE INDEX idx_fam_patient ON patient_family_history(patient_id);
CREATE INDEX idx_imm_patient ON patient_immunizations(patient_id);
CREATE INDEX idx_doc_patient ON patient_documents(patient_id);
CREATE INDEX idx_drug_master_name ON drug_master(name);
CREATE INDEX idx_drug_master_generic ON drug_master(generic_name);
CREATE INDEX idx_drug_master_barcode ON drug_master(barcode);
CREATE INDEX idx_drug_master_schedule ON drug_master(schedule);
CREATE INDEX idx_purchase_inv_date ON purchase_invoices(invoice_date);
CREATE INDEX idx_purchase_inv_wholesaler ON purchase_invoices(wholesaler_id);
CREATE INDEX idx_pii_invoice ON purchase_invoice_items(invoice_id);
CREATE INDEX idx_pii_drug ON purchase_invoice_items(drug_master_id);
CREATE INDEX idx_batch_drug_expiry ON drug_stock_batches(drug_master_id, expiry);
CREATE INDEX idx_batch_active ON drug_stock_batches(is_active, qty_remaining);
CREATE INDEX idx_disp_date ON dispensing_register(dispensed_at);
CREATE INDEX idx_disp_schedule ON dispensing_register(schedule, dispensed_at);
CREATE INDEX idx_disp_patient ON dispensing_register(patient_id);
CREATE INDEX idx_patients_place ON patients(place, district);
CREATE INDEX idx_beds_ward ON beds(ward_id, status);
CREATE INDEX idx_bed_transfers_adm ON bed_transfers(admission_id, transferred_at);
CREATE INDEX idx_ip_notes_adm ON ip_progress_notes(admission_id, noted_at);
CREATE INDEX idx_ip_vitals_adm ON ip_vitals(admission_id, recorded_at);
CREATE INDEX idx_ip_medord_adm ON ip_medication_orders(admission_id, status);
CREATE INDEX idx_ip_medadmin_adm ON ip_medication_admin(admission_id, administered_at);
CREATE INDEX idx_ip_io_adm ON ip_intake_output(admission_id, recorded_at);
CREATE INDEX idx_ip_nursing_adm ON ip_nursing_notes(admission_id, noted_at);
CREATE INDEX idx_ip_diet_adm ON ip_diet_orders(admission_id);
CREATE INDEX idx_ip_xconsult_adm ON ip_cross_consultations(admission_id, status);
CREATE INDEX idx_mlc_admission ON mlc_register(admission_id);
CREATE INDEX idx_mlc_corr ON mlc_correspondence(mlc_id, occurred_at);
CREATE INDEX idx_body_release_adm ON body_release(admission_id);
CREATE INDEX idx_bill_items_bill ON bill_items(bill_id);
CREATE UNIQUE INDEX idx_bill_items_accrual_once
      ON bill_items(bill_id, source, source_ref_id, accrual_date)
      WHERE accrual_date IS NOT NULL;
CREATE INDEX idx_bill_payments_bill ON bill_payments(bill_id);
CREATE INDEX idx_advances_patient ON advances(patient_id);
CREATE INDEX idx_advances_admission ON advances(admission_id);
CREATE INDEX idx_tpa_claims_status ON tpa_claims(status);
CREATE INDEX idx_tpa_claims_admission ON tpa_claims(admission_id);
CREATE INDEX idx_discharge_tpl_dept ON discharge_templates(department, doctor_id);
CREATE INDEX idx_print_jobs_status ON print_jobs(status, created_at);
CREATE INDEX idx_adm_req_status ON admission_requests(status, requested_at);
CREATE INDEX idx_peds_growth_patient ON peds_growth_measurements(patient_id, measured_on);
CREATE INDEX idx_peds_vax_patient ON peds_vaccine_records(patient_id, due_date);
CREATE INDEX idx_tpa_events_claim ON tpa_claim_events(claim_id, occurred_at);
CREATE UNIQUE INDEX idx_bed_single_active_admission
             ON ip_admissions(bed_id) WHERE bed_id IS NOT NULL AND status='admitted';
CREATE INDEX idx_bills_patient ON bills(patient_id);
CREATE INDEX idx_bills_created ON bills(created_at);
CREATE INDEX idx_bills_lab_order ON bills(lab_order_id);
CREATE INDEX idx_wa_queue_status_sched
      ON wa_message_queue(status, scheduled_at);
CREATE INDEX idx_wa_messages_conv
      ON wa_messages(conversation_id, timestamp);
CREATE INDEX idx_wa_webhook_processed
      ON wa_webhook_events(processed, created_at);
CREATE INDEX idx_wa_campaigns_account
      ON wa_campaigns(account_id, status);
CREATE INDEX idx_wa_camp_recip_campaign
      ON wa_campaign_recipients(campaign_id, status);
CREATE UNIQUE INDEX ux_radiology_tests_name ON radiology_tests(name COLLATE NOCASE);
CREATE INDEX idx_radiology_orders_patient ON radiology_orders(patient_id);
CREATE INDEX idx_radiology_orders_status ON radiology_orders(status, ordered_at);
CREATE INDEX idx_radiology_orders_appt ON radiology_orders(appointment_id);
CREATE INDEX idx_radiology_items_order ON radiology_order_items(order_id);
CREATE INDEX idx_bills_radiology_order ON bills(radiology_order_id);
COMMIT;