PRAGMA foreign_keys=OFF;
BEGIN;
CREATE TABLE schema_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
CREATE TABLE patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uhid TEXT NOT NULL UNIQUE,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      dob TEXT NOT NULL,
      gender TEXT NOT NULL CHECK (gender IN ('M','F','Other')),
      phone TEXT NOT NULL,
      email TEXT,
      address TEXT,
      blood_group TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , place TEXT, district TEXT, state TEXT, profession TEXT, registration_fee_paid INTEGER NOT NULL DEFAULT 0, registration_fee_paid_at TEXT, row_version INTEGER NOT NULL DEFAULT 1);
CREATE TABLE doctors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      specialty TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      room_number TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      default_fee REAL NOT NULL DEFAULT 500
    , signature TEXT, qualifications TEXT, registration_no TEXT, color TEXT, available_from TEXT, available_to TEXT, template_id INTEGER);
CREATE TABLE appointments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      doctor_id INTEGER NOT NULL REFERENCES doctors(id),
      appointment_date TEXT NOT NULL,
      appointment_time TEXT NOT NULL,
      token_number INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'Waiting',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , consultation_token TEXT, row_version INTEGER NOT NULL DEFAULT 1);
CREATE TABLE bills (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_number TEXT NOT NULL UNIQUE,
      appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      items_json TEXT NOT NULL,
      subtotal REAL NOT NULL,
      discount REAL NOT NULL DEFAULT 0,
      discount_type TEXT NOT NULL DEFAULT 'flat',
      total REAL NOT NULL,
      payment_mode TEXT NOT NULL,
      paid_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    , is_free_followup INTEGER NOT NULL DEFAULT 0, followup_parent_appt_id INTEGER REFERENCES appointments(id), is_relaxed_followup INTEGER NOT NULL DEFAULT 0, doctor_id INTEGER REFERENCES doctors(id), notes TEXT, bill_kind TEXT NOT NULL DEFAULT 'opd');
CREATE TABLE notification_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      sent_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );
CREATE TABLE consultations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id) ON DELETE CASCADE,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      doctor_id INTEGER NOT NULL REFERENCES doctors(id),
      history TEXT,
      vitals_json TEXT,
      examination TEXT,
      impression TEXT,
      advice TEXT,
      follow_up_date TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    , row_version INTEGER NOT NULL DEFAULT 1, extra_fields_json TEXT);
CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      salt TEXT NOT NULL,
      role TEXT NOT NULL,
      display_name TEXT,
      doctor_id INTEGER REFERENCES doctors(id),
      is_active INTEGER NOT NULL DEFAULT 1,
      last_login_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      username TEXT,
      role TEXT,
      action TEXT NOT NULL,
      entity TEXT,
      entity_id INTEGER,
      details TEXT,
      at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE prescription_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      appointment_id INTEGER NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
      drug_name TEXT NOT NULL,
      dosage TEXT,
      frequency TEXT,
      duration TEXT,
      instructions TEXT,
      order_idx INTEGER NOT NULL DEFAULT 0
    , drug_master_id INTEGER REFERENCES drug_master(id));
CREATE TABLE lab_tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price REAL NOT NULL DEFAULT 0,
      sample_type TEXT,
      ref_range TEXT,
      unit TEXT,
      is_active INTEGER NOT NULL DEFAULT 1
    );
CREATE TABLE lab_orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT NOT NULL UNIQUE,
      appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      doctor_id INTEGER REFERENCES doctors(id),
      status TEXT NOT NULL DEFAULT 'ordered',
      ordered_at TEXT NOT NULL DEFAULT (datetime('now')),
      collected_at TEXT,
      reported_at TEXT,
      notes TEXT
    );
CREATE TABLE lab_order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      lab_order_id INTEGER NOT NULL REFERENCES lab_orders(id) ON DELETE CASCADE,
      lab_test_id INTEGER REFERENCES lab_tests(id),
      test_name TEXT NOT NULL,
      result TEXT,
      unit TEXT,
      ref_range TEXT,
      is_abnormal INTEGER DEFAULT 0
    );
CREATE TABLE drug_inventory (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      generic_name TEXT,
      form TEXT,
      strength TEXT,
      mrp REAL NOT NULL DEFAULT 0,
      purchase_price REAL,
      batch TEXT,
      expiry TEXT,
      stock_qty INTEGER NOT NULL DEFAULT 0,
      low_stock_threshold INTEGER NOT NULL DEFAULT 10,
      is_active INTEGER NOT NULL DEFAULT 1
    );
CREATE TABLE pharmacy_sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_number TEXT NOT NULL UNIQUE,
      patient_id INTEGER REFERENCES patients(id),
      appointment_id INTEGER REFERENCES appointments(id),
      subtotal REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      payment_mode TEXT,
      sold_by TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE pharmacy_sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL REFERENCES pharmacy_sales(id) ON DELETE CASCADE,
      drug_id INTEGER REFERENCES drug_inventory(id),
      drug_name TEXT NOT NULL,
      qty INTEGER NOT NULL,
      rate REAL NOT NULL,
      amount REAL NOT NULL
    , drug_master_id INTEGER REFERENCES drug_master(id), batch_id INTEGER REFERENCES drug_stock_batches(id), gst_amount REAL DEFAULT 0);
CREATE TABLE ip_admissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      admission_number TEXT NOT NULL UNIQUE,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      admission_doctor_id INTEGER REFERENCES doctors(id),
      admitted_at TEXT NOT NULL DEFAULT (datetime('now')),
      discharged_at TEXT,
      bed_number TEXT,
      ward TEXT,
      admission_notes TEXT,
      discharge_summary TEXT,
      status TEXT NOT NULL DEFAULT 'admitted'
    );
CREATE TABLE patient_allergies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      allergen TEXT NOT NULL,
      reaction TEXT,
      severity TEXT,
      noted_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE patient_conditions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      condition TEXT NOT NULL,
      since TEXT,
      notes TEXT,
      is_active INTEGER DEFAULT 1
    );
CREATE TABLE patient_family_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      relation TEXT NOT NULL,
      condition TEXT NOT NULL,
      notes TEXT
    );
CREATE TABLE patient_immunizations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      vaccine TEXT NOT NULL,
      given_at TEXT,
      dose TEXT,
      notes TEXT
    );
CREATE TABLE patient_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      file_name TEXT NOT NULL,
      file_type TEXT,
      file_path TEXT NOT NULL,
      size_bytes INTEGER,
      note TEXT,
      uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE drug_master (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      generic_name TEXT,
      manufacturer TEXT,
      form TEXT,
      strength TEXT,
      pack_size INTEGER,
      schedule TEXT NOT NULL DEFAULT 'OTC' CHECK (schedule IN ('H','H1','G','X','OTC')),
      hsn_code TEXT,
      gst_rate REAL NOT NULL DEFAULT 12,
      default_mrp REAL NOT NULL DEFAULT 0,
      low_stock_threshold INTEGER NOT NULL DEFAULT 10,
      barcode TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE wholesalers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      contact_person TEXT,
      phone TEXT,
      email TEXT,
      address TEXT,
      drug_license_no TEXT NOT NULL,
      gstin TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE purchase_invoices (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_number TEXT NOT NULL,
      wholesaler_id INTEGER NOT NULL REFERENCES wholesalers(id) ON DELETE RESTRICT,
      invoice_date TEXT NOT NULL,
      received_date TEXT NOT NULL DEFAULT (date('now')),
      subtotal REAL NOT NULL DEFAULT 0,
      cgst REAL NOT NULL DEFAULT 0,
      sgst REAL NOT NULL DEFAULT 0,
      igst REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      payment_mode TEXT,
      payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('paid','unpaid','partial')),
      scan_path TEXT,
      ocr_job_id INTEGER,
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (wholesaler_id, invoice_number)
    );
CREATE TABLE purchase_invoice_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_id INTEGER NOT NULL REFERENCES purchase_invoices(id) ON DELETE CASCADE,
      drug_master_id INTEGER NOT NULL REFERENCES drug_master(id) ON DELETE RESTRICT,
      batch_no TEXT NOT NULL,
      expiry TEXT NOT NULL,
      qty_received INTEGER NOT NULL,
      pack_qty INTEGER,
      free_qty INTEGER NOT NULL DEFAULT 0,
      purchase_price REAL NOT NULL,
      mrp REAL NOT NULL,
      gst_rate REAL NOT NULL DEFAULT 12,
      manufacturer_license_no TEXT,
      line_total REAL NOT NULL DEFAULT 0
    );
CREATE TABLE drug_stock_batches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      drug_master_id INTEGER NOT NULL REFERENCES drug_master(id) ON DELETE RESTRICT,
      purchase_item_id INTEGER REFERENCES purchase_invoice_items(id) ON DELETE SET NULL,
      batch_no TEXT NOT NULL,
      expiry TEXT NOT NULL,
      qty_received INTEGER NOT NULL,
      qty_remaining INTEGER NOT NULL,
      purchase_price REAL,
      mrp REAL NOT NULL DEFAULT 0,
      manufacturer_license_no TEXT,
      received_at TEXT NOT NULL DEFAULT (date('now')),
      is_active INTEGER NOT NULL DEFAULT 1,
      UNIQUE (drug_master_id, batch_no)
    );
CREATE TABLE dispensing_register (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_item_id INTEGER NOT NULL REFERENCES pharmacy_sale_items(id) ON DELETE RESTRICT,
      sale_id INTEGER NOT NULL REFERENCES pharmacy_sales(id) ON DELETE RESTRICT,
      patient_id INTEGER REFERENCES patients(id),
      doctor_id INTEGER REFERENCES doctors(id),
      drug_master_id INTEGER NOT NULL REFERENCES drug_master(id),
      batch_id INTEGER NOT NULL REFERENCES drug_stock_batches(id),
      batch_no TEXT NOT NULL,
      expiry TEXT NOT NULL,
      schedule TEXT NOT NULL,
      qty INTEGER NOT NULL,
      rate REAL NOT NULL,
      rx_reference TEXT,
      dispensed_at TEXT NOT NULL DEFAULT (datetime('now')),
      dispensed_by TEXT
    );
INSERT INTO "schema_meta" ("key","value") VALUES ('version','2');
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (1,'LEG-initial-1','Patinitialx1','Legacy','1984-03-01','F','9746000001',NULL,'Old Market Road','B+','2026-10-21 14:20:11',NULL,NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (2,'LEG-initial-2','Patinitialx2','Legacy','1984-03-02','M','9746000002',NULL,'Old Market Road','B+','2026-10-21 14:20:11',NULL,NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (3,'LEG-v030-1','Patv030x1','Legacy','1984-03-01','F','9265000001',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (4,'LEG-v030-2','Patv030x2','Legacy','1984-03-02','M','9265000002',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (5,'LEG-v040-1','Patv040x1','Legacy','1984-03-01','F','9266000001',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at","place","district","state","profession","registration_fee_paid","registration_fee_paid_at","row_version") VALUES (6,'LEG-v040-2','Patv040x2','Legacy','1984-03-02','M','9266000002',NULL,'Old Market Road','B+','2026-10-21 14:20:12','Mulgund',NULL,NULL,NULL,0,NULL,1);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id") VALUES (1,'Dr. Legacy initial','General',NULL,NULL,NULL,1,300,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id") VALUES (2,'Dr. Legacy v030','General',NULL,NULL,NULL,1,300,NULL,'MBBS','REG-v030',NULL,NULL,NULL,NULL);
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee","signature","qualifications","registration_no","color","available_from","available_to","template_id") VALUES (3,'Dr. Legacy v040','General',NULL,NULL,NULL,1,300,NULL,'MBBS','REG-v040',NULL,NULL,NULL,NULL);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version") VALUES (1,1,1,'2026-04-01','10:30',1,'completed','legacy visit initial','2026-10-21 14:20:11',NULL,1);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version") VALUES (2,2,1,'2026-04-02','11:30',2,'completed','legacy visit initial','2026-10-21 14:20:11',NULL,1);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version") VALUES (3,3,2,'2026-04-01','10:30',1,'completed','legacy visit v030','2026-10-21 14:20:12',NULL,1);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version") VALUES (4,4,2,'2026-04-02','11:30',2,'completed','legacy visit v030','2026-10-21 14:20:12',NULL,1);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version") VALUES (5,5,3,'2026-04-01','10:30',1,'completed','legacy visit v040','2026-10-21 14:20:12',NULL,1);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at","consultation_token","row_version") VALUES (6,6,3,'2026-04-02','11:30',2,'completed','legacy visit v040','2026-10-21 14:20:12',NULL,1);
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (1,'LEG-initial-B1',1,1,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:11',0,NULL,0,NULL,NULL,'opd');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (2,'LEG-initial-B2',2,2,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:11',0,NULL,0,NULL,NULL,'opd');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (3,'LEG-v030-B1',3,3,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (4,'LEG-v030-B2',4,4,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (5,'LEG-v030-IPD1',NULL,4,'[]',0,0,'flat',0,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (6,'LEG-v040-B1',5,5,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:12',0,NULL,0,NULL,'legacy bill v040','consultation');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (7,'LEG-v040-B2',6,6,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,'legacy bill v040','consultation');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at","is_free_followup","followup_parent_appt_id","is_relaxed_followup","doctor_id","notes","bill_kind") VALUES (8,'LEG-v040-IPD1',NULL,6,'[]',0,0,'flat',0,'Pending',NULL,'2026-10-21 14:20:12',0,NULL,0,NULL,NULL,'opd');
INSERT INTO "settings" ("key","value") VALUES ('clinic_name','Legacy Clinic v040');
INSERT INTO "settings" ("key","value") VALUES ('clinic_phone','9000011111');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_initial','kept');
INSERT INTO "settings" ("key","value") VALUES ('clinic_address','1st Floor, Arihant Plaza, Rotary Circle, Gadag - 582 101');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_v030','kept');
INSERT INTO "settings" ("key","value") VALUES ('followup_enabled','true');
INSERT INTO "settings" ("key","value") VALUES ('followup_window_days','7');
INSERT INTO "settings" ("key","value") VALUES ('followup_free_visits','2');
INSERT INTO "settings" ("key","value") VALUES ('followup_grace_days','2');
INSERT INTO "settings" ("key","value") VALUES ('registration_fee_enabled','true');
INSERT INTO "settings" ("key","value") VALUES ('registration_fee_amount','100');
INSERT INTO "settings" ("key","value") VALUES ('registration_fee_default_timing','ask');
INSERT INTO "settings" ("key","value") VALUES ('misc_services','Procedure,Vaccination,Nebulization,Wound Dressing,Injection,Suture / Stitches,IV Fluids,Other');
INSERT INTO "settings" ("key","value") VALUES ('network_mode','local');
INSERT INTO "settings" ("key","value") VALUES ('network_listen_port','4321');
INSERT INTO "settings" ("key","value") VALUES ('network_server_url','');
INSERT INTO "settings" ("key","value") VALUES ('network_secret','');
INSERT INTO "settings" ("key","value") VALUES ('station_name','');
INSERT INTO "settings" ("key","value") VALUES ('slip_templates','[{"id":1,"name":"General","specialty_hint":"Default short layout","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":55,"printed":true},{"key":"examination","title":"Examination","type":"textarea","height_mm":60,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":60,"printed":true}]},{"id":2,"name":"General Medicine","specialty_hint":"Full medicine workup — past / personal / family / systemic exam","sections":[{"key":"history","title":"Chief Complaints","type":"textarea","height_mm":35,"placeholder":"Presenting complaints with onset, duration, progression","printed":true},{"key":"past_history","title":"Past History","type":"textarea","height_mm":18,"placeholder":"DM · HTN · TB · IHD · Surgeries · Allergies","printed":true},{"key":"personal_history","title":"Personal History","type":"textarea","height_mm":18,"placeholder":"Diet · Sleep · Bowel · Bladder · Addictions (smoking / alcohol / tobacco)","printed":true},{"key":"family_history","title":"Family History","type":"textarea","height_mm":14,"placeholder":"Heritable / chronic illnesses in immediate family","printed":true},{"key":"general_exam","title":"General Examination","type":"textarea","height_mm":22,"placeholder":"Pallor · Icterus · Cyanosis · Clubbing · Lymphadenopathy · Edema","printed":true},{"key":"examination","title":"Systemic Examination (CVS · RS · P/A · CNS)","type":"textarea","height_mm":35,"printed":true},{"key":"impression","title":"Provisional Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":3,"name":"OBG","specialty_hint":"Obstetrics & Gynaecology","sections":[{"key":"lmp","title":"LMP (Last Menstrual Period)","type":"date","printed":true},{"key":"edd","title":"EDD (Expected Date of Delivery)","type":"date","printed":true},{"key":"parity","title":"G / P / A / L","type":"singleline","height_mm":8,"placeholder":"e.g. G2 P1 A0 L1","printed":true},{"key":"gestational_age","title":"Gestational Age","type":"singleline","height_mm":8,"placeholder":"e.g. 28 wks 3 days","printed":true},{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":40,"printed":true},{"key":"examination","title":"P/A & P/V Examination","type":"textarea","height_mm":40,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":4,"name":"Pediatrics","specialty_hint":"Children — feeding, milestones, immunization","sections":[{"key":"feeding","title":"Feeding History","type":"textarea","height_mm":18,"printed":true},{"key":"milestones","title":"Developmental Milestones","type":"textarea","height_mm":18,"printed":true},{"key":"immunization","title":"Immunization Status","type":"singleline","height_mm":8,"placeholder":"e.g. Up to date / Partial / Pending DPT-3","printed":true},{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":40,"printed":true},{"key":"examination","title":"Examination","type":"textarea","height_mm":40,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":50,"printed":true}]},{"id":5,"name":"Cardiology","specialty_hint":"Heart-focused workflow with NYHA, sounds, ECG","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":35,"printed":true},{"key":"exertional","title":"Exertional Capacity / NYHA Class","type":"singleline","height_mm":8,"placeholder":"e.g. NYHA II — breathless on climbing 1 flight","printed":true},{"key":"heart_sounds","title":"Heart Sounds / Murmurs","type":"textarea","height_mm":22,"placeholder":"S1 S2 normal · No added sounds · No murmur","printed":true},{"key":"ecg_findings","title":"ECG / Echo Findings","type":"textarea","height_mm":22,"printed":true},{"key":"examination","title":"Other Examination","type":"textarea","height_mm":22,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":45,"printed":true}]},{"id":6,"name":"Orthopedic","specialty_hint":"Site, ROM, deformities","sections":[{"key":"site","title":"Site / Side","type":"singleline","height_mm":8,"placeholder":"e.g. Right knee · Left shoulder","printed":true},{"key":"mechanism","title":"Mechanism of Injury","type":"textarea","height_mm":18,"placeholder":"How did the injury happen?","printed":true},{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":30,"printed":true},{"key":"rom","title":"Range of Motion (ROM)","type":"textarea","height_mm":18,"placeholder":"Flexion / Extension / Abduction / Rotation","printed":true},{"key":"deformities","title":"Deformities / Tenderness","type":"textarea","height_mm":18,"printed":true},{"key":"examination","title":"Other Examination","type":"textarea","height_mm":22,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":40,"printed":true}]},{"id":7,"name":"ENT","specialty_hint":"Ear · Nose · Throat — otoscopy, tuning fork, nasal, throat","sections":[{"key":"history","title":"Chief Complaints / History","type":"textarea","height_mm":35,"placeholder":"Onset, duration, side, associated symptoms","printed":true},{"key":"otoscopy_right","title":"Otoscopy — Right Ear","type":"textarea","height_mm":18,"placeholder":"EAC · TM appearance · Cone of light · Discharge","printed":true},{"key":"otoscopy_left","title":"Otoscopy — Left Ear","type":"textarea","height_mm":18,"placeholder":"EAC · TM appearance · Cone of light · Discharge","printed":true},{"key":"hearing","title":"Hearing Assessment","type":"singleline","height_mm":8,"placeholder":"e.g. Whisper test passed · Audiometry pending","printed":true},{"key":"tuning_fork","title":"Tuning Fork Tests","type":"textarea","height_mm":14,"placeholder":"Rinne · Weber · ABC","printed":true},{"key":"nasal","title":"Nasal Examination","type":"textarea","height_mm":18,"placeholder":"Septum · Turbinates · Discharge · Polyps","printed":true},{"key":"throat","title":"Throat / Pharynx Examination","type":"textarea","height_mm":18,"placeholder":"Tonsils · Posterior pharyngeal wall · Uvula","printed":true},{"key":"examination","title":"Other Examination","type":"textarea","height_mm":18,"printed":true},{"key":"impression","title":"Impression / Diagnosis","type":"textarea","height_mm":22,"printed":true},{"key":"advice","title":"Advice / Prescription (Rx)","type":"textarea","height_mm":40,"printed":true}]}]');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_v040','kept');
INSERT INTO "users" ("id","username","password_hash","salt","role","display_name","doctor_id","is_active","last_login_at","created_at") VALUES (1,'legacy_v030','not-a-real-hash-v030','','staff',NULL,NULL,1,NULL,'2026-10-21 14:20:12');
INSERT INTO "users" ("id","username","password_hash","salt","role","display_name","doctor_id","is_active","last_login_at","created_at") VALUES (2,'legacy_v040','not-a-real-hash-v040','','staff',NULL,NULL,1,NULL,'2026-10-21 14:20:12');
INSERT INTO "lab_tests" ("id","name","price","sample_type","ref_range","unit","is_active") VALUES (1,'Legacy CBC v030',250,NULL,NULL,'',1);
INSERT INTO "lab_tests" ("id","name","price","sample_type","ref_range","unit","is_active") VALUES (2,'Legacy CBC v040',250,NULL,NULL,'',1);
INSERT INTO "lab_orders" ("id","order_number","appointment_id","patient_id","doctor_id","status","ordered_at","collected_at","reported_at","notes") VALUES (1,'LEG-v030-LAB1',NULL,3,2,'ordered','2026-10-21 14:20:12',NULL,NULL,NULL);
INSERT INTO "lab_orders" ("id","order_number","appointment_id","patient_id","doctor_id","status","ordered_at","collected_at","reported_at","notes") VALUES (2,'LEG-v040-LAB1',NULL,5,3,'ordered','2026-10-21 14:20:12',NULL,NULL,NULL);
INSERT INTO "lab_order_items" ("id","lab_order_id","lab_test_id","test_name","result","unit","ref_range","is_abnormal") VALUES (1,1,1,'Legacy CBC v030','12.5','g/dL',NULL,0);
INSERT INTO "lab_order_items" ("id","lab_order_id","lab_test_id","test_name","result","unit","ref_range","is_abnormal") VALUES (2,2,2,'Legacy CBC v040','12.5','g/dL',NULL,0);
INSERT INTO "pharmacy_sales" ("id","sale_number","patient_id","appointment_id","subtotal","discount","total","payment_mode","sold_by","created_at") VALUES (1,'LEG-v030-S1',3,NULL,1000,0,1000,'Cash','desk','2026-10-21 14:20:12');
INSERT INTO "pharmacy_sales" ("id","sale_number","patient_id","appointment_id","subtotal","discount","total","payment_mode","sold_by","created_at") VALUES (2,'LEG-v040-S1',5,NULL,1000,0,1000,'Cash','desk','2026-10-21 14:20:12');
INSERT INTO "pharmacy_sale_items" ("id","sale_id","drug_id","drug_name","qty","rate","amount","drug_master_id","batch_id","gst_amount") VALUES (1,1,NULL,'Legacy Drug v030',10,100,1000,1,1,0);
INSERT INTO "pharmacy_sale_items" ("id","sale_id","drug_id","drug_name","qty","rate","amount","drug_master_id","batch_id","gst_amount") VALUES (2,2,NULL,'Legacy Drug v040',10,100,1000,2,2,0);
INSERT INTO "ip_admissions" ("id","admission_number","patient_id","admission_doctor_id","admitted_at","discharged_at","bed_number","ward","admission_notes","discharge_summary","status") VALUES (1,'LEG-v030-IP1',4,NULL,'2026-10-21 14:20:12',NULL,NULL,NULL,NULL,NULL,'admitted');
INSERT INTO "ip_admissions" ("id","admission_number","patient_id","admission_doctor_id","admitted_at","discharged_at","bed_number","ward","admission_notes","discharge_summary","status") VALUES (2,'LEG-v040-IP1',6,NULL,'2026-10-21 14:20:12',NULL,NULL,NULL,NULL,NULL,'admitted');
INSERT INTO "drug_master" ("id","name","generic_name","manufacturer","form","strength","pack_size","schedule","hsn_code","gst_rate","default_mrp","low_stock_threshold","barcode","is_active","notes","created_at","updated_at") VALUES (1,'Legacy Drug v030',NULL,NULL,'Tablet','500mg',NULL,'OTC',NULL,12,100,10,NULL,1,NULL,'2026-10-21 14:20:12','2026-10-21 14:20:12');
INSERT INTO "drug_master" ("id","name","generic_name","manufacturer","form","strength","pack_size","schedule","hsn_code","gst_rate","default_mrp","low_stock_threshold","barcode","is_active","notes","created_at","updated_at") VALUES (2,'Legacy Drug v040',NULL,NULL,'Tablet','500mg',NULL,'OTC',NULL,12,100,10,NULL,1,NULL,'2026-10-21 14:20:12','2026-10-21 14:20:12');
INSERT INTO "wholesalers" ("id","name","contact_person","phone","email","address","drug_license_no","gstin","is_active","notes","created_at") VALUES (1,'Legacy Supplier v030',NULL,NULL,NULL,NULL,'DL-v030',NULL,1,NULL,'2026-10-21 14:20:12');
INSERT INTO "wholesalers" ("id","name","contact_person","phone","email","address","drug_license_no","gstin","is_active","notes","created_at") VALUES (2,'Legacy Supplier v040',NULL,NULL,NULL,NULL,'DL-v040',NULL,1,NULL,'2026-10-21 14:20:12');
INSERT INTO "purchase_invoices" ("id","invoice_number","wholesaler_id","invoice_date","received_date","subtotal","cgst","sgst","igst","discount","total","payment_mode","payment_status","scan_path","ocr_job_id","notes","created_at") VALUES (1,'LEG-v030-INV',1,'2026-04-05','2026-10-21',5000,0,0,0,0,5000,NULL,'paid',NULL,NULL,NULL,'2026-10-21 14:20:12');
INSERT INTO "purchase_invoices" ("id","invoice_number","wholesaler_id","invoice_date","received_date","subtotal","cgst","sgst","igst","discount","total","payment_mode","payment_status","scan_path","ocr_job_id","notes","created_at") VALUES (2,'LEG-v040-INV',2,'2026-04-05','2026-10-21',5000,0,0,0,0,5000,NULL,'paid',NULL,NULL,NULL,'2026-10-21 14:20:12');
INSERT INTO "purchase_invoice_items" ("id","invoice_id","drug_master_id","batch_no","expiry","qty_received","pack_qty","free_qty","purchase_price","mrp","gst_rate","manufacturer_license_no","line_total") VALUES (1,1,1,'PB-v030','2030-01-01',100,NULL,0,50,100,12,NULL,5000);
INSERT INTO "purchase_invoice_items" ("id","invoice_id","drug_master_id","batch_no","expiry","qty_received","pack_qty","free_qty","purchase_price","mrp","gst_rate","manufacturer_license_no","line_total") VALUES (2,2,2,'PB-v040','2030-01-01',100,NULL,0,50,100,12,NULL,5000);
INSERT INTO "drug_stock_batches" ("id","drug_master_id","purchase_item_id","batch_no","expiry","qty_received","qty_remaining","purchase_price","mrp","manufacturer_license_no","received_at","is_active") VALUES (1,1,1,'PB-v030','2030-01-01',100,90,50,100,NULL,'2026-10-21',1);
INSERT INTO "drug_stock_batches" ("id","drug_master_id","purchase_item_id","batch_no","expiry","qty_received","qty_remaining","purchase_price","mrp","manufacturer_license_no","received_at","is_active") VALUES (2,2,2,'PB-v040','2030-01-01',100,90,50,100,NULL,'2026-10-21',1);
INSERT INTO "dispensing_register" ("id","sale_item_id","sale_id","patient_id","doctor_id","drug_master_id","batch_id","batch_no","expiry","schedule","qty","rate","rx_reference","dispensed_at","dispensed_by") VALUES (1,1,1,3,NULL,1,1,'PB-v030','2030-01-01','OTC',10,100,NULL,'2026-10-21 14:20:12',NULL);
INSERT INTO "dispensing_register" ("id","sale_item_id","sale_id","patient_id","doctor_id","drug_master_id","batch_id","batch_no","expiry","schedule","qty","rate","rx_reference","dispensed_at","dispensed_by") VALUES (2,2,2,5,NULL,2,2,'PB-v040','2030-01-01','OTC',10,100,NULL,'2026-10-21 14:20:12',NULL);
DELETE FROM sqlite_sequence WHERE name='doctors';
INSERT INTO sqlite_sequence (name, seq) VALUES ('doctors', 3);
DELETE FROM sqlite_sequence WHERE name='patients';
INSERT INTO sqlite_sequence (name, seq) VALUES ('patients', 6);
DELETE FROM sqlite_sequence WHERE name='appointments';
INSERT INTO sqlite_sequence (name, seq) VALUES ('appointments', 6);
DELETE FROM sqlite_sequence WHERE name='bills';
INSERT INTO sqlite_sequence (name, seq) VALUES ('bills', 8);
DELETE FROM sqlite_sequence WHERE name='lab_tests';
INSERT INTO sqlite_sequence (name, seq) VALUES ('lab_tests', 2);
DELETE FROM sqlite_sequence WHERE name='lab_orders';
INSERT INTO sqlite_sequence (name, seq) VALUES ('lab_orders', 2);
DELETE FROM sqlite_sequence WHERE name='lab_order_items';
INSERT INTO sqlite_sequence (name, seq) VALUES ('lab_order_items', 2);
DELETE FROM sqlite_sequence WHERE name='ip_admissions';
INSERT INTO sqlite_sequence (name, seq) VALUES ('ip_admissions', 2);
DELETE FROM sqlite_sequence WHERE name='drug_master';
INSERT INTO sqlite_sequence (name, seq) VALUES ('drug_master', 2);
DELETE FROM sqlite_sequence WHERE name='wholesalers';
INSERT INTO sqlite_sequence (name, seq) VALUES ('wholesalers', 2);
DELETE FROM sqlite_sequence WHERE name='purchase_invoices';
INSERT INTO sqlite_sequence (name, seq) VALUES ('purchase_invoices', 2);
DELETE FROM sqlite_sequence WHERE name='purchase_invoice_items';
INSERT INTO sqlite_sequence (name, seq) VALUES ('purchase_invoice_items', 2);
DELETE FROM sqlite_sequence WHERE name='drug_stock_batches';
INSERT INTO sqlite_sequence (name, seq) VALUES ('drug_stock_batches', 2);
DELETE FROM sqlite_sequence WHERE name='pharmacy_sales';
INSERT INTO sqlite_sequence (name, seq) VALUES ('pharmacy_sales', 2);
DELETE FROM sqlite_sequence WHERE name='pharmacy_sale_items';
INSERT INTO sqlite_sequence (name, seq) VALUES ('pharmacy_sale_items', 2);
DELETE FROM sqlite_sequence WHERE name='dispensing_register';
INSERT INTO sqlite_sequence (name, seq) VALUES ('dispensing_register', 2);
DELETE FROM sqlite_sequence WHERE name='users';
INSERT INTO sqlite_sequence (name, seq) VALUES ('users', 2);
CREATE INDEX idx_patients_phone ON patients(phone);
CREATE INDEX idx_patients_name ON patients(first_name, last_name);
CREATE INDEX idx_appt_date_doctor ON appointments(appointment_date, doctor_id);
CREATE INDEX idx_appt_patient ON appointments(patient_id);
CREATE INDEX idx_bills_patient ON bills(patient_id);
CREATE INDEX idx_bills_created ON bills(created_at);
CREATE INDEX idx_notif_status ON notification_log(status);
CREATE INDEX idx_consult_patient ON consultations(patient_id);
CREATE INDEX idx_audit_at ON audit_log(at);
CREATE INDEX idx_rx_appt ON prescription_items(appointment_id);
CREATE INDEX idx_lab_orders_patient ON lab_orders(patient_id);
CREATE INDEX idx_drug_name ON drug_inventory(name);
CREATE INDEX idx_ip_status ON ip_admissions(status);
CREATE INDEX idx_allergy_patient ON patient_allergies(patient_id);
CREATE INDEX idx_cond_patient ON patient_conditions(patient_id);
CREATE INDEX idx_fam_patient ON patient_family_history(patient_id);
CREATE INDEX idx_imm_patient ON patient_immunizations(patient_id);
CREATE INDEX idx_doc_patient ON patient_documents(patient_id);
CREATE INDEX idx_drug_master_name ON drug_master(name);
CREATE INDEX idx_drug_master_generic ON drug_master(generic_name);
CREATE INDEX idx_drug_master_barcode ON drug_master(barcode);
CREATE INDEX idx_drug_master_schedule ON drug_master(schedule);
CREATE INDEX idx_purchase_inv_date ON purchase_invoices(invoice_date);
CREATE INDEX idx_purchase_inv_wholesaler ON purchase_invoices(wholesaler_id);
CREATE INDEX idx_pii_invoice ON purchase_invoice_items(invoice_id);
CREATE INDEX idx_pii_drug ON purchase_invoice_items(drug_master_id);
CREATE INDEX idx_batch_drug_expiry ON drug_stock_batches(drug_master_id, expiry);
CREATE INDEX idx_batch_active ON drug_stock_batches(is_active, qty_remaining);
CREATE INDEX idx_disp_date ON dispensing_register(dispensed_at);
CREATE INDEX idx_disp_schedule ON dispensing_register(schedule, dispensed_at);
CREATE INDEX idx_disp_patient ON dispensing_register(patient_id);
CREATE INDEX idx_patients_place ON patients(place, district);
COMMIT;