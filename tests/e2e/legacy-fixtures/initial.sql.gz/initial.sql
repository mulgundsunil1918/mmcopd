PRAGMA foreign_keys=OFF;
BEGIN;
CREATE TABLE schema_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
CREATE TABLE patients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uhid TEXT NOT NULL UNIQUE,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      dob TEXT NOT NULL,
      gender TEXT NOT NULL CHECK (gender IN ('M','F','Other')),
      phone TEXT NOT NULL,
      email TEXT,
      address TEXT,
      blood_group TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE doctors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      specialty TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      room_number TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      default_fee REAL NOT NULL DEFAULT 500
    );
CREATE TABLE appointments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
      doctor_id INTEGER NOT NULL REFERENCES doctors(id),
      appointment_date TEXT NOT NULL,
      appointment_time TEXT NOT NULL,
      token_number INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'Waiting',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE bills (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bill_number TEXT NOT NULL UNIQUE,
      appointment_id INTEGER REFERENCES appointments(id) ON DELETE SET NULL,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      items_json TEXT NOT NULL,
      subtotal REAL NOT NULL,
      discount REAL NOT NULL DEFAULT 0,
      discount_type TEXT NOT NULL DEFAULT 'flat',
      total REAL NOT NULL,
      payment_mode TEXT NOT NULL,
      paid_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE notification_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      patient_id INTEGER REFERENCES patients(id) ON DELETE SET NULL,
      type TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      sent_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
CREATE TABLE settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );
CREATE TABLE consultations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id) ON DELETE CASCADE,
      patient_id INTEGER NOT NULL REFERENCES patients(id),
      doctor_id INTEGER NOT NULL REFERENCES doctors(id),
      history TEXT,
      vitals_json TEXT,
      examination TEXT,
      impression TEXT,
      advice TEXT,
      follow_up_date TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
INSERT INTO "schema_meta" ("key","value") VALUES ('version','1');
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at") VALUES (1,'LEG-initial-1','Patinitialx1','Legacy','1984-03-01','F','9746000001',NULL,'Old Market Road','B+','2026-10-21 14:20:11');
INSERT INTO "patients" ("id","uhid","first_name","last_name","dob","gender","phone","email","address","blood_group","created_at") VALUES (2,'LEG-initial-2','Patinitialx2','Legacy','1984-03-02','M','9746000002',NULL,'Old Market Road','B+','2026-10-21 14:20:11');
INSERT INTO "doctors" ("id","name","specialty","phone","email","room_number","is_active","default_fee") VALUES (1,'Dr. Legacy initial','General',NULL,NULL,NULL,1,300);
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at") VALUES (1,1,1,'2026-04-01','10:30',1,'completed','legacy visit initial','2026-10-21 14:20:11');
INSERT INTO "appointments" ("id","patient_id","doctor_id","appointment_date","appointment_time","token_number","status","notes","created_at") VALUES (2,2,1,'2026-04-02','11:30',2,'completed','legacy visit initial','2026-10-21 14:20:11');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at") VALUES (1,'LEG-initial-B1',1,1,'[{"description":"OPD Consultation","qty":1,"rate":300,"amount":300}]',300,0,'flat',300,'Cash','2026-04-01T10:00:00.000Z','2026-10-21 14:20:11');
INSERT INTO "bills" ("id","bill_number","appointment_id","patient_id","items_json","subtotal","discount","discount_type","total","payment_mode","paid_at","created_at") VALUES (2,'LEG-initial-B2',2,2,'[{"description":"OPD Consultation","qty":1,"rate":400,"amount":400}]',400,0,'flat',400,'Pending',NULL,'2026-10-21 14:20:11');
INSERT INTO "settings" ("key","value") VALUES ('clinic_name','Legacy Clinic initial');
INSERT INTO "settings" ("key","value") VALUES ('clinic_phone','9000011111');
INSERT INTO "settings" ("key","value") VALUES ('legacy_marker_initial','kept');
DELETE FROM sqlite_sequence WHERE name='doctors';
INSERT INTO sqlite_sequence (name, seq) VALUES ('doctors', 1);
DELETE FROM sqlite_sequence WHERE name='patients';
INSERT INTO sqlite_sequence (name, seq) VALUES ('patients', 2);
DELETE FROM sqlite_sequence WHERE name='appointments';
INSERT INTO sqlite_sequence (name, seq) VALUES ('appointments', 2);
DELETE FROM sqlite_sequence WHERE name='bills';
INSERT INTO sqlite_sequence (name, seq) VALUES ('bills', 2);
CREATE INDEX idx_patients_phone ON patients(phone);
CREATE INDEX idx_patients_name ON patients(first_name, last_name);
CREATE INDEX idx_appt_date_doctor ON appointments(appointment_date, doctor_id);
CREATE INDEX idx_appt_patient ON appointments(patient_id);
CREATE INDEX idx_bills_patient ON bills(patient_id);
CREATE INDEX idx_bills_created ON bills(created_at);
CREATE INDEX idx_notif_status ON notification_log(status);
CREATE INDEX idx_consult_patient ON consultations(patient_id);
COMMIT;